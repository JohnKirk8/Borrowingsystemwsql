﻿using System.Data.SqlClient;

namespace BorrowingSystemApp
{
    public static class DbConfig
    {
        public static string ConnectionString = @"Server=(localdb)\MSSQLLocalDB;Database=BorrowingSystemDB;Integrated Security=True;";

        public static SqlConnection GetConnection()
        {
            return new SqlConnection(ConnectionString);
        }
    }
}