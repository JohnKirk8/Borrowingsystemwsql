﻿namespace BorrowingSystemApp
{
    partial class ItemsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ItemsForm));
            txtItemCode = new TextBox();
            txtItemName = new TextBox();
            txtTotalQty = new TextBox();
            txtAvailableQty = new TextBox();
            btnAdd = new Button();
            btnUpdate = new Button();
            btnDelete = new Button();
            btnClear = new Button();
            dgvItems = new DataGridView();
            txtSearch = new TextBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            cmbCategory = new ComboBox();
            panel1 = new Panel();
            lblCurrentUser = new Label();
            label7 = new Label();
            pictureBox1 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)dgvItems).BeginInit();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // txtItemCode
            // 
            txtItemCode.Location = new Point(206, 154);
            txtItemCode.Margin = new Padding(4, 5, 4, 5);
            txtItemCode.Name = "txtItemCode";
            txtItemCode.Size = new Size(132, 27);
            txtItemCode.TabIndex = 0;
            txtItemCode.Text = "ITM-001";
            // 
            // txtItemName
            // 
            txtItemName.Location = new Point(206, 210);
            txtItemName.Margin = new Padding(4, 5, 4, 5);
            txtItemName.Name = "txtItemName";
            txtItemName.Size = new Size(132, 27);
            txtItemName.TabIndex = 1;
            txtItemName.Text = "Epson Projector";
            // 
            // txtTotalQty
            // 
            txtTotalQty.Location = new Point(206, 324);
            txtTotalQty.Margin = new Padding(4, 5, 4, 5);
            txtTotalQty.Name = "txtTotalQty";
            txtTotalQty.Size = new Size(132, 27);
            txtTotalQty.TabIndex = 3;
            txtTotalQty.Text = "5";
            // 
            // txtAvailableQty
            // 
            txtAvailableQty.Location = new Point(206, 379);
            txtAvailableQty.Margin = new Padding(4, 5, 4, 5);
            txtAvailableQty.Name = "txtAvailableQty";
            txtAvailableQty.Size = new Size(132, 27);
            txtAvailableQty.TabIndex = 4;
            txtAvailableQty.Text = "5";
            // 
            // btnAdd
            // 
            btnAdd.Location = new Point(54, 507);
            btnAdd.Margin = new Padding(4, 5, 4, 5);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(100, 35);
            btnAdd.TabIndex = 5;
            btnAdd.Text = "Add";
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.Click += btnAdd_Click;
            // 
            // btnUpdate
            // 
            btnUpdate.Location = new Point(162, 507);
            btnUpdate.Margin = new Padding(4, 5, 4, 5);
            btnUpdate.Name = "btnUpdate";
            btnUpdate.Size = new Size(100, 35);
            btnUpdate.TabIndex = 6;
            btnUpdate.Text = "Update";
            btnUpdate.UseVisualStyleBackColor = true;
            btnUpdate.Click += btnUpdate_Click;
            // 
            // btnDelete
            // 
            btnDelete.Location = new Point(270, 507);
            btnDelete.Margin = new Padding(4, 5, 4, 5);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(100, 35);
            btnDelete.TabIndex = 7;
            btnDelete.Text = "Delete";
            btnDelete.UseVisualStyleBackColor = true;
            btnDelete.Click += btnDelete_Click;
            // 
            // btnClear
            // 
            btnClear.Location = new Point(382, 507);
            btnClear.Margin = new Padding(4, 5, 4, 5);
            btnClear.Name = "btnClear";
            btnClear.Size = new Size(100, 35);
            btnClear.TabIndex = 8;
            btnClear.Text = "Clear";
            btnClear.UseVisualStyleBackColor = true;
            btnClear.Click += btnClear_Click;
            // 
            // dgvItems
            // 
            dgvItems.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvItems.Location = new Point(380, 154);
            dgvItems.Margin = new Padding(4, 5, 4, 5);
            dgvItems.Name = "dgvItems";
            dgvItems.RowHeadersWidth = 51;
            dgvItems.Size = new Size(657, 231);
            dgvItems.TabIndex = 9;
            dgvItems.CellClick += dgvItems_CellClick;
            // 
            // txtSearch
            // 
            txtSearch.Location = new Point(448, 114);
            txtSearch.Margin = new Padding(4, 5, 4, 5);
            txtSearch.Name = "txtSearch";
            txtSearch.Size = new Size(252, 27);
            txtSearch.TabIndex = 12;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(382, 119);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(56, 20);
            label1.TabIndex = 11;
            label1.Text = "Search:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(54, 157);
            label2.Name = "label2";
            label2.Size = new Size(59, 20);
            label2.TabIndex = 13;
            label2.Text = "Item id:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(54, 217);
            label3.Name = "label3";
            label3.Size = new Size(83, 20);
            label3.TabIndex = 14;
            label3.Text = "Item name:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(54, 274);
            label4.Name = "label4";
            label4.Size = new Size(72, 20);
            label4.TabIndex = 15;
            label4.Text = "Category:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(54, 327);
            label5.Name = "label5";
            label5.Size = new Size(103, 20);
            label5.TabIndex = 16;
            label5.Text = "Total quantity:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(54, 379);
            label6.Name = "label6";
            label6.Size = new Size(132, 20);
            label6.TabIndex = 17;
            label6.Text = "Available quantity:";
            // 
            // cmbCategory
            // 
            cmbCategory.FormattingEnabled = true;
            cmbCategory.Location = new Point(206, 274);
            cmbCategory.Name = "cmbCategory";
            cmbCategory.Size = new Size(132, 28);
            cmbCategory.TabIndex = 18;
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(30, 41, 59);
            panel1.Controls.Add(lblCurrentUser);
            panel1.Controls.Add(label7);
            panel1.Controls.Add(pictureBox1);
            panel1.Location = new Point(-12, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1101, 57);
            panel1.TabIndex = 20;
            // 
            // lblCurrentUser
            // 
            lblCurrentUser.AutoSize = true;
            lblCurrentUser.BackColor = SystemColors.ButtonHighlight;
            lblCurrentUser.Location = new Point(895, 23);
            lblCurrentUser.Name = "lblCurrentUser";
            lblCurrentUser.Size = new Size(137, 20);
            lblCurrentUser.TabIndex = 21;
            lblCurrentUser.Text = "Logged in as: None";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 16F);
            label7.ForeColor = SystemColors.ButtonHighlight;
            label7.Location = new Point(95, 9);
            label7.Name = "label7";
            label7.Size = new Size(191, 37);
            label7.TabIndex = 22;
            label7.Text = "Manage Item's";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(17, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(71, 67);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 23;
            pictureBox1.TabStop = false;
            // 
            // ItemsForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1067, 692);
            Controls.Add(panel1);
            Controls.Add(cmbCategory);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(txtSearch);
            Controls.Add(label1);
            Controls.Add(dgvItems);
            Controls.Add(btnClear);
            Controls.Add(btnDelete);
            Controls.Add(btnUpdate);
            Controls.Add(btnAdd);
            Controls.Add(txtAvailableQty);
            Controls.Add(txtTotalQty);
            Controls.Add(txtItemName);
            Controls.Add(txtItemCode);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Margin = new Padding(4, 5, 4, 5);
            Name = "ItemsForm";
            Text = "ItemsForm";
            Load += ItemsForm_Load;
            ((System.ComponentModel.ISupportInitialize)dgvItems).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtItemCode;
        private TextBox txtItemName;
        private TextBox txtTotalQty;
        private TextBox txtAvailableQty;
        private Button btnAdd;
        private Button btnUpdate;
        private Button btnDelete;
        private Button btnClear;
        private DataGridView dgvItems;
        private TextBox txtSearch;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private ComboBox cmbCategory;
        private Panel panel1;
        private Label label7;
        private PictureBox pictureBox1;
        private Label lblCurrentUser;
    }
}