﻿using System;
using System.Data.SqlClient;

namespace BorrowingSystemApp
{
    public static class AuditLogger
    {
        public static void Log(string actionType, string recordReference, string details = "")
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(DbConfig.ConnectionString))
                {
                    conn.Open();
                    string query = @"INSERT INTO AuditLogs (Username, ActionType, RecordReference, Details, Timestamp) 
                                    VALUES (@Username, @ActionType, @RecordRef, @Details, GETDATE())";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@Username", UserSession.Username ?? "Unknown");
                        cmd.Parameters.AddWithValue("@ActionType", actionType);
                        cmd.Parameters.AddWithValue("@RecordRef", recordReference);
                        cmd.Parameters.AddWithValue("@Details", details);
                        cmd.ExecuteNonQuery();
                    }
                }
            }
            catch
            {
                // Silent fail so logging errors do not crash the primary transaction
            }
        }
    }
}