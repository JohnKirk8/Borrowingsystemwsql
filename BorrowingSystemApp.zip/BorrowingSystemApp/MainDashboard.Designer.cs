﻿namespace BorrowingSystemApp
{
    partial class MainDashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainDashboard));
            btnItems = new Button();
            btnLogout = new Button();
            btnBorrowers = new Button();
            btnTransactions = new Button();
            SuspendLayout();
            // 
            // btnItems
            // 
            btnItems.Location = new Point(44, 69);
            btnItems.Margin = new Padding(4, 5, 4, 5);
            btnItems.Name = "btnItems";
            btnItems.Size = new Size(144, 35);
            btnItems.TabIndex = 0;
            btnItems.Text = "Manage Items";
            btnItems.UseVisualStyleBackColor = true;
            btnItems.Click += btnItems_Click;
            // 
            // btnLogout
            // 
            btnLogout.Location = new Point(44, 272);
            btnLogout.Margin = new Padding(4, 5, 4, 5);
            btnLogout.Name = "btnLogout";
            btnLogout.Size = new Size(144, 35);
            btnLogout.TabIndex = 1;
            btnLogout.Text = "Logout";
            btnLogout.UseVisualStyleBackColor = true;
            btnLogout.Click += btnLogout_Click;
            // 
            // btnBorrowers
            // 
            btnBorrowers.Location = new Point(44, 132);
            btnBorrowers.Margin = new Padding(4, 5, 4, 5);
            btnBorrowers.Name = "btnBorrowers";
            btnBorrowers.Size = new Size(144, 35);
            btnBorrowers.TabIndex = 2;
            btnBorrowers.Text = "Manage Borrowers";
            btnBorrowers.UseVisualStyleBackColor = true;
            // 
            // btnTransactions
            // 
            btnTransactions.Location = new Point(44, 203);
            btnTransactions.Margin = new Padding(4, 5, 4, 5);
            btnTransactions.Name = "btnTransactions";
            btnTransactions.Size = new Size(144, 35);
            btnTransactions.TabIndex = 3;
            btnTransactions.Text = "Borrow / Return";
            btnTransactions.UseVisualStyleBackColor = true;
            btnTransactions.Click += btnTransactions_Click_1;
            // 
            // MainDashboard
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(233, 388);
            Controls.Add(btnTransactions);
            Controls.Add(btnBorrowers);
            Controls.Add(btnLogout);
            Controls.Add(btnItems);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Margin = new Padding(4, 5, 4, 5);
            Name = "MainDashboard";
            Text = "Form2";
            Load += MainDashboard_Load;
            ResumeLayout(false);
        }

        #endregion

        private Button btnItems;
        private Button btnLogout;
        private Button btnBorrowers;
        private Button btnTransactions;
    }
}