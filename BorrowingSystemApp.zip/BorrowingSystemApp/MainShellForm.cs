﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace BorrowingSystemApp
{
    public partial class MainShellForm : Form
    {
        public MainShellForm()
        {
            InitializeComponent();
        }

        private void MainShellForm_Load(object sender, EventArgs e)
        {

        }
    }
}
