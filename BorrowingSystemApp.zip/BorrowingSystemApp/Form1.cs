using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace BorrowingSystemApp
{
    public partial class Form1 : Form
    {
        // View State & Mode Flags
        private bool isRegisterMode = false;
        private int selectedItemID = 0;
        private int selectedBorrowerID = 0;
        private int selectedTransactionID = 0;

        // Multi-Item Borrowing Cart Data Structure
        private DataTable dtCart;

        // UI View Panels
        private Panel pnlLoginOverlay;
        private Panel pnlMainContainer;
        private Panel pnlSidebar;
        private Panel pnlTopHeader;
        private Panel pnlContentArea;

        // Dynamic Sub-Panels
        private Panel pnlDashboardView;
        private Panel pnlItemsView;
        private Panel pnlBorrowersView;
        private Panel pnlTransactionsView;
        private Panel pnlHistoryView;

        // Login Controls
        private TextBox txtUsername;
        private TextBox txtPassword;
        private Button btnLogin;
        private LinkLabel lnkToggle;

        // Navigation Controls
        private Label lblHeaderTitle;
        private Label lblHeaderUser;
        private Button btnNavDashboard;
        private Button btnNavItems;
        private Button btnNavBorrowers;
        private Button btnNavTransactions;
        private Button btnNavHistory;
        private Button btnNavLogout;

        // Items Controls
        private TextBox txtItemCode;
        private TextBox txtItemName;
        private ComboBox cmbCategory;
        private TextBox txtTotalQty;
        private TextBox txtAvailableQty;
        private TextBox txtItemSearch;
        private DataGridView dgvItems;

        // Borrowers Controls
        private TextBox txtBorrowerCode;
        private TextBox txtBorrowerName;
        private TextBox txtBorrowerEmail;
        private TextBox txtBorrowerPhone;
        private TextBox txtBorrowerSearch;
        private DataGridView dgvBorrowers;

        // Transactions Controls (With Multi-Item Cart & Detail Expansion)
        private ComboBox cmbTxBorrower;
        private ComboBox cmbTxItem;
        private TextBox txtTxQty;
        private DateTimePicker dtpTxDueDate;
        private DataGridView dgvCart;
        private TextBox txtTxSearch;
        private DataGridView dgvTransactions;
        private Button btnExpandTxItems;

        // Borrower History Controls
        private ComboBox cmbHistoryBorrower;
        private Label lblHistoryStatus;
        private Label lblHistTotalBorrows;
        private Label lblHistActiveBorrows;
        private Label lblHistOverdueBorrows;
        private Label lblHistLateReturns;
        private DataGridView dgvBorrowerHistory;

        // Dashboard Stats Controls
        private Label lblStatTotalItems;
        private Label lblStatAvailableItems;
        private Label lblStatTotalBorrowers;
        private Label lblStatActiveBorrows;
        private DataGridView dgvRecentActivity;

        public Form1()
        {
            InitializeComponent();

            // 1. DISABLE WINFORMS AUTOMATIC DPI / FONT RESCALING
            this.AutoScaleMode = AutoScaleMode.None;

            // 2. LOCK WINDOW DIMENSIONS TO PERFECTLY FIT CANVAS
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = true;
            this.ClientSize = new Size(1180, 740);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.FromArgb(244, 246, 249);

            InitializeCartTable();
            BuildProgrammaticUI();
            ShowLoginOverlay();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Event handler bound in designer
        }

        private void InitializeCartTable()
        {
            dtCart = new DataTable();
            dtCart.Columns.Add("ItemID", typeof(int));
            dtCart.Columns.Add("ItemCode", typeof(string));
            dtCart.Columns.Add("ItemName", typeof(string));
            dtCart.Columns.Add("Quantity", typeof(int));
            dtCart.Columns.Add("AvailableStock", typeof(int));
        }

        #region Failsafe Validation Helpers

        private bool IsDuplicateValue(string tableName, string columnName, string value, string idColumnName = "", int currentId = 0)
        {
            using (SqlConnection conn = DbConfig.GetConnection())
            {
                try
                {
                    conn.Open();
                    string query = $"SELECT COUNT(*) FROM {tableName} WHERE LOWER({columnName}) = LOWER(@Value)";
                    if (currentId > 0 && !string.IsNullOrEmpty(idColumnName))
                    {
                        query += $" AND {idColumnName} <> @CurrentID";
                    }
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@Value", value.Trim());
                        if (currentId > 0 && !string.IsNullOrEmpty(idColumnName))
                        {
                            cmd.Parameters.AddWithValue("@CurrentID", currentId);
                        }
                        int count = Convert.ToInt32(cmd.ExecuteScalar());
                        return count > 0;
                    }
                }
                catch
                {
                    return false;
                }
            }
        }

        private bool IsValidEmail(string email)
        {
            if (string.IsNullOrWhiteSpace(email)) return false;
            string pattern = @"^[^@\s]+@[^@\s]+\.[^@\s]+$";
            return Regex.IsMatch(email, pattern, RegexOptions.IgnoreCase);
        }

        private void ClampAvailableQuantity()
        {
            if (int.TryParse(txtTotalQty.Text.Trim(), out int total) &&
                int.TryParse(txtAvailableQty.Text.Trim(), out int avail))
            {
                if (avail > total)
                {
                    txtAvailableQty.Text = total.ToString();
                }
            }
        }

        #endregion

        #region UI Construction & Navigation

        private void BuildProgrammaticUI()
        {
            this.Controls.Clear();

            // 1. Main Application Container
            pnlMainContainer = new Panel { Dock = DockStyle.Fill, Visible = false };
            this.Controls.Add(pnlMainContainer);

            // Top Header
            pnlTopHeader = new Panel
            {
                Dock = DockStyle.Top,
                Height = 55,
                BackColor = Color.White
            };
            pnlTopHeader.Paint += (s, e) =>
            {
                using (Pen p = new Pen(Color.FromArgb(226, 232, 240)))
                    e.Graphics.DrawLine(p, 0, pnlTopHeader.Height - 1, pnlTopHeader.Width, pnlTopHeader.Height - 1);
            };

            lblHeaderTitle = new Label
            {
                Text = "Dashboard Overview",
                Font = new Font("Segoe UI", 13f, FontStyle.Bold),
                ForeColor = Color.FromArgb(30, 41, 59),
                Location = new Point(20, 14),
                AutoSize = true
            };
            lblHeaderUser = new Label
            {
                Text = "Logged in as: -",
                Font = new Font("Segoe UI", 9.5f, FontStyle.Regular),
                ForeColor = Color.FromArgb(100, 116, 139),
                Dock = DockStyle.Right,
                TextAlign = ContentAlignment.MiddleRight,
                Padding = new Padding(0, 0, 20, 0),
                AutoSize = false,
                Width = 350
            };
            pnlTopHeader.Controls.Add(lblHeaderTitle);
            pnlTopHeader.Controls.Add(lblHeaderUser);

            // Left Sidebar
            pnlSidebar = new Panel
            {
                Dock = DockStyle.Left,
                Width = 220,
                BackColor = Color.FromArgb(30, 41, 59)
            };

            Label lblAppLogo = new Label
            {
                Text = "BORROW SYS",
                Font = new Font("Segoe UI", 12f, FontStyle.Bold),
                ForeColor = Color.White,
                Location = new Point(20, 16),
                AutoSize = true
            };
            pnlSidebar.Controls.Add(lblAppLogo);

            btnNavDashboard = CreateNavButton("Dashboard", 70);
            btnNavItems = CreateNavButton("Items Inventory", 115);
            btnNavBorrowers = CreateNavButton("Borrowers", 160);
            btnNavTransactions = CreateNavButton("Transactions", 205);
            btnNavHistory = CreateNavButton("Borrower History", 250);
            btnNavLogout = CreateNavButton("Logout", 305, Color.FromArgb(220, 38, 38));

            btnNavDashboard.Click += (s, e) => SwitchTab("Dashboard");
            btnNavItems.Click += (s, e) => SwitchTab("Items");
            btnNavBorrowers.Click += (s, e) => SwitchTab("Borrowers");
            btnNavTransactions.Click += (s, e) => SwitchTab("Transactions");
            btnNavHistory.Click += (s, e) => SwitchTab("History");
            btnNavLogout.Click += btnLogout_Click;

            pnlSidebar.Controls.AddRange(new Control[] { btnNavDashboard, btnNavItems, btnNavBorrowers, btnNavTransactions, btnNavHistory, btnNavLogout });

            // Main Dynamic Content Area
            pnlContentArea = new Panel { Dock = DockStyle.Fill, BackColor = Color.FromArgb(244, 246, 249), Padding = new Padding(20) };

            pnlMainContainer.Controls.Add(pnlContentArea);
            pnlMainContainer.Controls.Add(pnlTopHeader);
            pnlMainContainer.Controls.Add(pnlSidebar);

            // 2. Login Overlay View
            BuildLoginOverlay();

            // 3. Build Feature Sub-Panels
            BuildDashboardPanel();
            BuildItemsPanel();
            BuildBorrowersPanel();
            BuildTransactionsPanel();
            BuildHistoryPanel();
        }

        private Button CreateNavButton(string text, int top, Color? customHover = null)
        {
            Button btn = new Button
            {
                Text = "  " + text,
                Top = top,
                Left = 10,
                Width = 200,
                Height = 38,
                FlatStyle = FlatStyle.Flat,
                ForeColor = Color.FromArgb(226, 232, 240),
                BackColor = Color.Transparent,
                Font = new Font("Segoe UI", 9.5f, FontStyle.Bold),
                TextAlign = ContentAlignment.MiddleLeft,
                Cursor = Cursors.Hand
            };
            btn.FlatAppearance.BorderSize = 0;
            btn.MouseEnter += (s, e) => btn.BackColor = customHover ?? Color.FromArgb(51, 65, 85);
            btn.MouseLeave += (s, e) => btn.BackColor = Color.Transparent;
            return btn;
        }

        private void SwitchTab(string tabName)
        {
            pnlContentArea.Controls.Clear();
            lblHeaderTitle.Text = tabName == "Dashboard" ? "Dashboard Overview" : tabName + " Management";

            switch (tabName)
            {
                case "Dashboard":
                    pnlContentArea.Controls.Add(pnlDashboardView);
                    LoadDashboardData();
                    break;
                case "Items":
                    pnlContentArea.Controls.Add(pnlItemsView);
                    LoadCategoriesDropdown();
                    LoadItems();
                    AutoGenerateItemCode();
                    break;
                case "Borrowers":
                    pnlContentArea.Controls.Add(pnlBorrowersView);
                    LoadBorrowers();
                    break;
                case "Transactions":
                    pnlContentArea.Controls.Add(pnlTransactionsView);
                    LoadBorrowersDropdown();
                    LoadItemsDropdown();
                    LoadTransactions();
                    ClearCart();
                    break;
                case "History":
                    lblHeaderTitle.Text = "Borrower History & Penalty Tracker";
                    pnlContentArea.Controls.Add(pnlHistoryView);
                    LoadHistoryBorrowersDropdown();
                    break;
            }
        }

        private void ShowLoginOverlay()
        {
            pnlMainContainer.Visible = false;
            pnlLoginOverlay.Visible = true;
            pnlLoginOverlay.BringToFront();
        }

        private void ShowMainDashboard()
        {
            pnlLoginOverlay.Visible = false;
            pnlMainContainer.Visible = true;
            lblHeaderUser.Text = $"Logged in as: {UserSession.FullName} ({UserSession.Username})";
            SwitchTab("Dashboard");
        }

        #endregion

        #region Login & Registration View

        private void BuildLoginOverlay()
        {
            pnlLoginOverlay = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = Color.FromArgb(30, 41, 59)
            };

            Panel pnlCard = new Panel
            {
                Size = new Size(380, 420),
                BackColor = Color.White,
                Location = new Point((this.ClientSize.Width - 380) / 2, (this.ClientSize.Height - 420) / 2)
            };
            pnlLoginOverlay.Resize += (s, e) =>
            {
                pnlCard.Location = new Point((pnlLoginOverlay.Width - 380) / 2, (pnlLoginOverlay.Height - 420) / 2);
            };

            Label lblTitle = new Label
            {
                Text = "System Access",
                Font = new Font("Segoe UI", 16f, FontStyle.Bold),
                ForeColor = Color.FromArgb(30, 41, 59),
                Location = new Point(30, 30),
                AutoSize = true
            };

            Label lblSub = new Label
            {
                Text = "Please sign in to continue",
                Font = new Font("Segoe UI", 9f),
                ForeColor = Color.FromArgb(100, 116, 139),
                Location = new Point(30, 60),
                AutoSize = true
            };

            Label lblUser = new Label { Text = "Username", Location = new Point(30, 105), AutoSize = true, Font = new Font("Segoe UI", 9f, FontStyle.Bold) };
            txtUsername = new TextBox { Location = new Point(30, 128), Width = 320, Font = new Font("Segoe UI", 10f) };

            Label lblPass = new Label { Text = "Password", Location = new Point(30, 175), AutoSize = true, Font = new Font("Segoe UI", 9f, FontStyle.Bold) };
            txtPassword = new TextBox { Location = new Point(30, 198), Width = 320, PasswordChar = '•', Font = new Font("Segoe UI", 10f) };

            btnLogin = new Button
            {
                Text = "Login",
                Location = new Point(30, 260),
                Width = 320,
                Height = 40,
                BackColor = Color.FromArgb(37, 99, 235),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 10f, FontStyle.Bold),
                Cursor = Cursors.Hand
            };
            btnLogin.FlatAppearance.BorderSize = 0;
            btnLogin.Click += btnLogin_Click;

            lnkToggle = new LinkLabel
            {
                Text = "Don't have an account? Register",
                Location = new Point(30, 320),
                AutoSize = true,
                Font = new Font("Segoe UI", 9f),
                LinkColor = Color.FromArgb(37, 99, 235)
            };
            lnkToggle.LinkClicked += lnkToggle_LinkClicked;

            pnlCard.Controls.AddRange(new Control[] { lblTitle, lblSub, lblUser, txtUsername, lblPass, txtPassword, btnLogin, lnkToggle });
            pnlLoginOverlay.Controls.Add(pnlCard);
            this.Controls.Add(pnlLoginOverlay);
        }

        private void lnkToggle_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            isRegisterMode = !isRegisterMode;
            if (isRegisterMode)
            {
                btnLogin.Text = "Register Account";
                lnkToggle.Text = "Already have an account? Log in";
            }
            else
            {
                btnLogin.Text = "Login";
                lnkToggle.Text = "Don't have an account? Register";
            }
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text.Trim();
            string password = txtPassword.Text.Trim();

            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("Please enter both username and password.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (isRegisterMode) PerformRegistration(username, password);
            else PerformLogin(username, password);
        }

        private void PerformLogin(string username, string password)
        {
            using (SqlConnection conn = DbConfig.GetConnection())
            {
                try
                {
                    conn.Open();
                    string query = "SELECT UserID, Username, FullName FROM SystemUsers WHERE Username = @Username AND PasswordHash = @Password";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@Username", username);
                        cmd.Parameters.AddWithValue("@Password", password);
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                UserSession.UserID = Convert.ToInt32(reader["UserID"]);
                                UserSession.Username = reader["Username"].ToString();
                                UserSession.FullName = reader["FullName"]?.ToString() ?? reader["Username"].ToString();

                                txtPassword.Clear();
                                ShowMainDashboard();
                            }
                            else
                            {
                                MessageBox.Show("Invalid username or password.", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Database connection error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void PerformRegistration(string username, string password)
        {
            if (username.Length < 3)
            {
                MessageBox.Show("Username must be at least 3 characters long.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (IsDuplicateValue("SystemUsers", "Username", username))
            {
                MessageBox.Show("This username is already registered. Please choose another.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (SqlConnection conn = DbConfig.GetConnection())
            {
                try
                {
                    conn.Open();
                    string insertQuery = "INSERT INTO SystemUsers (Username, PasswordHash, FullName) VALUES (@Username, @Password, @Username)";
                    using (SqlCommand cmd = new SqlCommand(insertQuery, conn))
                    {
                        cmd.Parameters.AddWithValue("@Username", username);
                        cmd.Parameters.AddWithValue("@Password", password);
                        cmd.ExecuteNonQuery();
                    }

                    MessageBox.Show("Account created successfully! You can now log in.", "Registration Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    isRegisterMode = false;
                    btnLogin.Text = "Login";
                    lnkToggle.Text = "Don't have an account? Register";
                    txtPassword.Clear();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Registration error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            UserSession.ClearSession();
            ShowLoginOverlay();
        }

        #endregion

        #region Dashboard View

        private void BuildDashboardPanel()
        {
            pnlDashboardView = new Panel { Dock = DockStyle.Fill };

            Panel card1 = CreateStatCard("Total Inventory Items", "0", Color.FromArgb(37, 99, 235), 0, out lblStatTotalItems);
            Panel card2 = CreateStatCard("Available Stock Qty", "0", Color.FromArgb(16, 185, 129), 220, out lblStatAvailableItems);
            Panel card3 = CreateStatCard("Registered Borrowers", "0", Color.FromArgb(217, 119, 6), 440, out lblStatTotalBorrowers);
            Panel card4 = CreateStatCard("Active Borrowed Items", "0", Color.FromArgb(220, 38, 38), 660, out lblStatActiveBorrows);

            pnlDashboardView.Controls.AddRange(new Control[] { card1, card2, card3, card4 });

            Label lblRecent = new Label
            {
                Text = "Recent Transaction Activity",
                Font = new Font("Segoe UI", 11f, FontStyle.Bold),
                ForeColor = Color.FromArgb(30, 41, 59),
                Location = new Point(0, 125),
                AutoSize = true
            };
            pnlDashboardView.Controls.Add(lblRecent);

            dgvRecentActivity = new DataGridView
            {
                Location = new Point(0, 155),
                Size = new Size(920, 470),
                ReadOnly = true
            };
            StyleDataGridView(dgvRecentActivity);
            pnlDashboardView.Controls.Add(dgvRecentActivity);
        }

        private Panel CreateStatCard(string title, string value, Color borderAccent, int left, out Label lblValue)
        {
            Panel card = new Panel
            {
                Location = new Point(left, 0),
                Size = new Size(205, 95),
                BackColor = Color.White
            };
            card.Paint += (s, e) =>
            {
                using (Brush b = new SolidBrush(borderAccent))
                    e.Graphics.FillRectangle(b, 0, 0, 6, card.Height);
            };

            Label lblTitle = new Label
            {
                Text = title,
                Font = new Font("Segoe UI", 8.5f, FontStyle.Bold),
                ForeColor = Color.FromArgb(100, 116, 139),
                Location = new Point(16, 16),
                AutoSize = true
            };

            lblValue = new Label
            {
                Text = value,
                Font = new Font("Segoe UI", 20f, FontStyle.Bold),
                ForeColor = Color.FromArgb(30, 41, 59),
                Location = new Point(14, 40),
                AutoSize = true
            };

            card.Controls.Add(lblTitle);
            card.Controls.Add(lblValue);
            return card;
        }

        private void LoadDashboardData()
        {
            using (SqlConnection conn = DbConfig.GetConnection())
            {
                try
                {
                    conn.Open();
                    lblStatTotalItems.Text = new SqlCommand("SELECT ISNULL(COUNT(*), 0) FROM Items", conn).ExecuteScalar().ToString();
                    lblStatAvailableItems.Text = new SqlCommand("SELECT ISNULL(SUM(AvailableQty), 0) FROM Items", conn).ExecuteScalar().ToString();
                    lblStatTotalBorrowers.Text = new SqlCommand("SELECT ISNULL(COUNT(*), 0) FROM Borrowers", conn).ExecuteScalar().ToString();
                    lblStatActiveBorrows.Text = new SqlCommand("SELECT ISNULL(COUNT(*), 0) FROM BorrowTransactions WHERE Status = 'Borrowed'", conn).ExecuteScalar().ToString();

                    string recentQuery = @"SELECT TOP 10 
                                            t.TransactionID, 
                                            b.FullName AS [Borrower], 
                                            STUFF((
                                                SELECT ', ' + i.ItemName + ' (x' + CAST(d.Quantity AS VARCHAR) + ')'
                                                FROM BorrowDetails d
                                                INNER JOIN Items i ON d.ItemID = i.ItemID
                                                WHERE d.TransactionID = t.TransactionID
                                                FOR XML PATH('')
                                            ), 1, 2, '') AS [Items Borrowed],
                                            CONVERT(VARCHAR(10), t.BorrowDate, 120) AS [Borrow Date], 
                                            CONVERT(VARCHAR(10), t.DueDate, 120) AS [Due Date], 
                                            ISNULL(CONVERT(VARCHAR(10), t.ReturnDate, 120), 'Not Returned Yet') AS [Return Date],
                                            t.Status AS [Status] 
                                        FROM BorrowTransactions t
                                        INNER JOIN Borrowers b ON t.BorrowerID = b.BorrowerID
                                        ORDER BY t.TransactionID DESC";

                    SqlDataAdapter da = new SqlDataAdapter(recentQuery, conn);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dgvRecentActivity.DataSource = dt;
                    if (dgvRecentActivity.Columns["TransactionID"] != null)
                        dgvRecentActivity.Columns["TransactionID"].Visible = false;
                }
                catch { }
            }
        }

        #endregion

        #region Items Management View

        private void BuildItemsPanel()
        {
            pnlItemsView = new Panel { Dock = DockStyle.Fill };

            Panel pnlInputs = new Panel { Location = new Point(0, 0), Size = new Size(280, 620), BackColor = Color.White, Padding = new Padding(15) };

            pnlInputs.Controls.Add(new Label { Text = "Item Code", Location = new Point(15, 15), AutoSize = true, Font = new Font("Segoe UI", 9f, FontStyle.Bold) });
            txtItemCode = new TextBox { Location = new Point(15, 38), Width = 250, ReadOnly = true, BackColor = Color.FromArgb(241, 245, 249) };

            pnlInputs.Controls.Add(new Label { Text = "Item Name", Location = new Point(15, 75), AutoSize = true, Font = new Font("Segoe UI", 9f, FontStyle.Bold) });
            txtItemName = new TextBox { Location = new Point(15, 98), Width = 250 };

            pnlInputs.Controls.Add(new Label { Text = "Category", Location = new Point(15, 135), AutoSize = true, Font = new Font("Segoe UI", 9f, FontStyle.Bold) });
            cmbCategory = new ComboBox { Location = new Point(15, 158), Width = 250, DropDownStyle = ComboBoxStyle.DropDown };

            pnlInputs.Controls.Add(new Label { Text = "Total Quantity", Location = new Point(15, 195), AutoSize = true, Font = new Font("Segoe UI", 9f, FontStyle.Bold) });
            txtTotalQty = new TextBox { Location = new Point(15, 218), Width = 250 };
            txtTotalQty.Leave += (s, e) => ClampAvailableQuantity();

            pnlInputs.Controls.Add(new Label { Text = "Available Quantity", Location = new Point(15, 255), AutoSize = true, Font = new Font("Segoe UI", 9f, FontStyle.Bold) });
            txtAvailableQty = new TextBox { Location = new Point(15, 278), Width = 250 };
            txtAvailableQty.Leave += (s, e) => ClampAvailableQuantity();

            Button btnAdd = CreateActionButton("Add Item", Color.FromArgb(37, 99, 235), 330, btnAdd_Click);
            Button btnUpdate = CreateActionButton("Update Item", Color.FromArgb(217, 119, 6), 375, btnUpdateItem_Click);
            Button btnDelete = CreateActionButton("Delete Item", Color.FromArgb(220, 38, 38), 420, btnDeleteItem_Click);
            Button btnClear = CreateActionButton("Clear Form", Color.FromArgb(100, 116, 139), 465, (s, e) => ClearItemForm());

            pnlInputs.Controls.AddRange(new Control[] { txtItemCode, txtItemName, cmbCategory, txtTotalQty, txtAvailableQty, btnAdd, btnUpdate, btnDelete, btnClear });

            Label lblSearch = new Label { Text = "Search Items:", Location = new Point(300, 12), AutoSize = true, Font = new Font("Segoe UI", 9.5f, FontStyle.Bold) };
            txtItemSearch = new TextBox { Location = new Point(395, 8), Width = 300, Font = new Font("Segoe UI", 9.5f) };
            txtItemSearch.TextChanged += (s, e) => LoadItems(txtItemSearch.Text.Trim());

            dgvItems = new DataGridView { Location = new Point(300, 40), Size = new Size(620, 580), ReadOnly = true };
            StyleDataGridView(dgvItems);
            dgvItems.CellClick += dgvItems_CellClick;

            pnlItemsView.Controls.AddRange(new Control[] { pnlInputs, lblSearch, txtItemSearch, dgvItems });
        }

        private void LoadCategoriesDropdown()
        {
            using (SqlConnection conn = DbConfig.GetConnection())
            {
                try
                {
                    conn.Open();
                    string query = "SELECT DISTINCT Category FROM Items WHERE Category IS NOT NULL AND Category <> '' ORDER BY Category";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    SqlDataReader reader = cmd.ExecuteReader();
                    cmbCategory.Items.Clear();
                    while (reader.Read()) cmbCategory.Items.Add(reader["Category"].ToString());
                }
                catch { }
            }
        }

        private void LoadItems(string search = "")
        {
            using (SqlConnection conn = DbConfig.GetConnection())
            {
                try
                {
                    conn.Open();
                    string query = @"SELECT ItemID, ItemCode AS [Item Code], ItemName AS [Item Name], Category, TotalQty AS [Total Qty], AvailableQty AS [Available Qty] 
                                    FROM Items 
                                    WHERE ItemName LIKE @Search OR ItemCode LIKE @Search OR Category LIKE @Search
                                    ORDER BY ItemID DESC";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@Search", $"%{search}%");
                        SqlDataAdapter da = new SqlDataAdapter(cmd);
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        dgvItems.DataSource = dt;
                        if (dgvItems.Columns["ItemID"] != null) dgvItems.Columns["ItemID"].Visible = false;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error loading items: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void AutoGenerateItemCode()
        {
            using (SqlConnection conn = DbConfig.GetConnection())
            {
                try
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand("SELECT ItemCode FROM Items WHERE ItemCode LIKE 'ITM-%'", conn);
                    int maxNumber = 0;
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            string code = reader["ItemCode"].ToString().Trim();
                            if (code.Length >= 5 && int.TryParse(code.Substring(4), out int num))
                            {
                                if (num > maxNumber) maxNumber = num;
                            }
                        }
                    }
                    txtItemCode.Text = "ITM-" + (maxNumber + 1).ToString("D4");
                }
                catch
                {
                    txtItemCode.Text = "ITM-0001";
                }
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            string code = txtItemCode.Text.Trim();
            string name = txtItemName.Text.Trim();
            string category = cmbCategory.Text.Trim();

            if (string.IsNullOrWhiteSpace(code) || string.IsNullOrWhiteSpace(name))
            {
                MessageBox.Show("Item Code and Item Name cannot be empty.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (IsDuplicateValue("Items", "ItemCode", code))
            {
                MessageBox.Show("Item Code already exists.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (IsDuplicateValue("Items", "ItemName", name))
            {
                MessageBox.Show("An item with this name already exists.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!int.TryParse(txtTotalQty.Text.Trim(), out int totalQty) || totalQty < 0)
            {
                MessageBox.Show("Total Quantity must be a valid non-negative integer.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!int.TryParse(txtAvailableQty.Text.Trim(), out int availQty) || availQty < 0)
            {
                MessageBox.Show("Available Quantity must be a valid non-negative integer.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (availQty > totalQty)
            {
                availQty = totalQty;
                txtAvailableQty.Text = availQty.ToString();
            }

            using (SqlConnection conn = DbConfig.GetConnection())
            {
                try
                {
                    conn.Open();
                    string query = "INSERT INTO Items (ItemCode, ItemName, Category, TotalQty, AvailableQty) VALUES (@Code, @Name, @Category, @Total, @Available)";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@Code", code);
                        cmd.Parameters.AddWithValue("@Name", name);
                        cmd.Parameters.AddWithValue("@Category", string.IsNullOrWhiteSpace(category) ? (object)DBNull.Value : category);
                        cmd.Parameters.AddWithValue("@Total", totalQty);
                        cmd.Parameters.AddWithValue("@Available", availQty);
                        cmd.ExecuteNonQuery();
                    }
                    AuditLogger.Log("INSERT", $"Item Code: {code}", $"Added item '{name}'");
                    MessageBox.Show("Item added successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    ClearItemForm();
                    LoadCategoriesDropdown();
                    LoadItems();
                }
                catch (Exception ex) { MessageBox.Show("Error adding item: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error); }
            }
        }

        private void btnUpdateItem_Click(object sender, EventArgs e)
        {
            if (selectedItemID == 0)
            {
                MessageBox.Show("Please select an item from the list to update.", "Selection Required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string code = txtItemCode.Text.Trim();
            string name = txtItemName.Text.Trim();
            string category = cmbCategory.Text.Trim();

            if (string.IsNullOrWhiteSpace(code) || string.IsNullOrWhiteSpace(name))
            {
                MessageBox.Show("Item Code and Item Name cannot be empty.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (IsDuplicateValue("Items", "ItemCode", code, "ItemID", selectedItemID))
            {
                MessageBox.Show("Item Code is already assigned to another item.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (IsDuplicateValue("Items", "ItemName", name, "ItemID", selectedItemID))
            {
                MessageBox.Show("Another item with this name already exists.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!int.TryParse(txtTotalQty.Text.Trim(), out int totalQty) || totalQty < 0 ||
                !int.TryParse(txtAvailableQty.Text.Trim(), out int availQty) || availQty < 0)
            {
                MessageBox.Show("Please enter valid quantities.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (availQty > totalQty)
            {
                availQty = totalQty;
                txtAvailableQty.Text = availQty.ToString();
            }

            using (SqlConnection conn = DbConfig.GetConnection())
            {
                try
                {
                    conn.Open();
                    string query = "UPDATE Items SET ItemCode=@Code, ItemName=@Name, Category=@Category, TotalQty=@Total, AvailableQty=@Available WHERE ItemID=@ID";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@ID", selectedItemID);
                        cmd.Parameters.AddWithValue("@Code", code);
                        cmd.Parameters.AddWithValue("@Name", name);
                        cmd.Parameters.AddWithValue("@Category", string.IsNullOrWhiteSpace(category) ? (object)DBNull.Value : category);
                        cmd.Parameters.AddWithValue("@Total", totalQty);
                        cmd.Parameters.AddWithValue("@Available", availQty);
                        cmd.ExecuteNonQuery();
                    }
                    AuditLogger.Log("UPDATE", $"Item ID: {selectedItemID}", $"Updated item '{name}'");
                    MessageBox.Show("Item updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    ClearItemForm();
                    LoadItems();
                }
                catch (Exception ex) { MessageBox.Show("Error updating item: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error); }
            }
        }

        private void btnDeleteItem_Click(object sender, EventArgs e)
        {
            if (selectedItemID == 0)
            {
                MessageBox.Show("Please select an item from the list to delete.", "Selection Required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (MessageBox.Show("Are you sure you want to delete this item?", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;

            using (SqlConnection conn = DbConfig.GetConnection())
            {
                try
                {
                    conn.Open();

                    string checkTx = "SELECT COUNT(*) FROM BorrowDetails d INNER JOIN BorrowTransactions t ON d.TransactionID = t.TransactionID WHERE d.ItemID = @ID AND t.Status = 'Borrowed'";
                    using (SqlCommand checkCmd = new SqlCommand(checkTx, conn))
                    {
                        checkCmd.Parameters.AddWithValue("@ID", selectedItemID);
                        if (Convert.ToInt32(checkCmd.ExecuteScalar()) > 0)
                        {
                            MessageBox.Show("Cannot delete item because it is currently borrowed in an active transaction.", "Action Blocked", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                            return;
                        }
                    }

                    using (SqlCommand cmd = new SqlCommand("DELETE FROM Items WHERE ItemID=@ID", conn))
                    {
                        cmd.Parameters.AddWithValue("@ID", selectedItemID);
                        cmd.ExecuteNonQuery();
                    }
                    AuditLogger.Log("DELETE", $"Item ID: {selectedItemID}", $"Deleted item");
                    ClearItemForm();
                    LoadItems();
                }
                catch (Exception ex) { MessageBox.Show("Error deleting item: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error); }
            }
        }

        private void dgvItems_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.RowIndex < dgvItems.Rows.Count)
            {
                DataGridViewRow row = dgvItems.Rows[e.RowIndex];
                if (row.Cells["ItemID"].Value != DBNull.Value)
                {
                    selectedItemID = Convert.ToInt32(row.Cells["ItemID"].Value);
                    txtItemCode.Text = row.Cells["Item Code"].Value?.ToString();
                    txtItemName.Text = row.Cells["Item Name"].Value?.ToString();
                    cmbCategory.Text = row.Cells["Category"].Value?.ToString();
                    txtTotalQty.Text = row.Cells["Total Qty"].Value?.ToString();
                    txtAvailableQty.Text = row.Cells["Available Qty"].Value?.ToString();
                }
            }
        }

        private void ClearItemForm()
        {
            selectedItemID = 0;
            txtItemName.Clear();
            cmbCategory.Text = "";
            txtTotalQty.Clear();
            txtAvailableQty.Clear();
            AutoGenerateItemCode();
        }

        #endregion

        #region Borrowers Management View

        private void BuildBorrowersPanel()
        {
            pnlBorrowersView = new Panel { Dock = DockStyle.Fill };

            Panel pnlInputs = new Panel { Location = new Point(0, 0), Size = new Size(280, 620), BackColor = Color.White, Padding = new Padding(15) };

            pnlInputs.Controls.Add(new Label { Text = "Borrower Code", Location = new Point(15, 15), AutoSize = true, Font = new Font("Segoe UI", 9f, FontStyle.Bold) });
            txtBorrowerCode = new TextBox { Location = new Point(15, 38), Width = 250 };

            pnlInputs.Controls.Add(new Label { Text = "Full Name", Location = new Point(15, 75), AutoSize = true, Font = new Font("Segoe UI", 9f, FontStyle.Bold) });
            txtBorrowerName = new TextBox { Location = new Point(15, 98), Width = 250 };

            pnlInputs.Controls.Add(new Label { Text = "Email Address", Location = new Point(15, 135), AutoSize = true, Font = new Font("Segoe UI", 9f, FontStyle.Bold) });
            txtBorrowerEmail = new TextBox { Location = new Point(15, 158), Width = 250 };

            pnlInputs.Controls.Add(new Label { Text = "Phone Number", Location = new Point(15, 195), AutoSize = true, Font = new Font("Segoe UI", 9f, FontStyle.Bold) });
            txtBorrowerPhone = new TextBox { Location = new Point(15, 218), Width = 250 };

            Button btnAdd = CreateActionButton("Add Borrower", Color.FromArgb(37, 99, 235), 280, btnAddBorrower_Click);
            Button btnUpdate = CreateActionButton("Update Borrower", Color.FromArgb(217, 119, 6), 325, btnUpdateBorrower_Click);
            Button btnDelete = CreateActionButton("Delete Borrower", Color.FromArgb(220, 38, 38), 370, btnDeleteBorrower_Click);
            Button btnClear = CreateActionButton("Clear Form", Color.FromArgb(100, 116, 139), 415, (s, e) => ClearBorrowerForm());

            pnlInputs.Controls.AddRange(new Control[] { txtBorrowerCode, txtBorrowerName, txtBorrowerEmail, txtBorrowerPhone, btnAdd, btnUpdate, btnDelete, btnClear });

            Label lblSearch = new Label { Text = "Search Borrowers:", Location = new Point(300, 12), AutoSize = true, Font = new Font("Segoe UI", 9.5f, FontStyle.Bold) };
            txtBorrowerSearch = new TextBox { Location = new Point(420, 8), Width = 280, Font = new Font("Segoe UI", 9.5f) };
            txtBorrowerSearch.TextChanged += (s, e) => LoadBorrowers(txtBorrowerSearch.Text.Trim());

            dgvBorrowers = new DataGridView { Location = new Point(300, 40), Size = new Size(620, 580), ReadOnly = true };
            StyleDataGridView(dgvBorrowers);
            dgvBorrowers.CellClick += dgvBorrowers_CellClick;

            pnlBorrowersView.Controls.AddRange(new Control[] { pnlInputs, lblSearch, txtBorrowerSearch, dgvBorrowers });
        }

        private void LoadBorrowers(string search = "")
        {
            using (SqlConnection conn = DbConfig.GetConnection())
            {
                try
                {
                    conn.Open();
                    string query = @"SELECT BorrowerID, BorrowerCode AS [Borrower Code], FullName AS [Full Name], Email AS [Email Address], Phone AS [Phone Number] 
                                    FROM Borrowers 
                                    WHERE FullName LIKE @Search OR BorrowerCode LIKE @Search OR Email LIKE @Search
                                    ORDER BY BorrowerID DESC";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@Search", $"%{search}%");
                        SqlDataAdapter da = new SqlDataAdapter(cmd);
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        dgvBorrowers.DataSource = dt;
                        if (dgvBorrowers.Columns["BorrowerID"] != null) dgvBorrowers.Columns["BorrowerID"].Visible = false;
                    }
                }
                catch (Exception ex) { MessageBox.Show("Error loading borrowers: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error); }
            }
        }

        private void btnAddBorrower_Click(object sender, EventArgs e)
        {
            string code = txtBorrowerCode.Text.Trim();
            string name = txtBorrowerName.Text.Trim();
            string email = txtBorrowerEmail.Text.Trim();
            string phone = txtBorrowerPhone.Text.Trim();

            if (string.IsNullOrWhiteSpace(code) || string.IsNullOrWhiteSpace(name) || string.IsNullOrWhiteSpace(email) || string.IsNullOrWhiteSpace(phone))
            {
                MessageBox.Show("Please fill in all borrower details.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!IsValidEmail(email))
            {
                MessageBox.Show("Please enter a valid email address.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (IsDuplicateValue("Borrowers", "BorrowerCode", code))
            {
                MessageBox.Show("Borrower Code already exists.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (IsDuplicateValue("Borrowers", "Email", email))
            {
                MessageBox.Show("Email address is already registered to another borrower.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (SqlConnection conn = DbConfig.GetConnection())
            {
                try
                {
                    conn.Open();
                    string query = "INSERT INTO Borrowers (BorrowerCode, FullName, Email, Phone) VALUES (@Code, @Name, @Email, @Phone)";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@Code", code);
                        cmd.Parameters.AddWithValue("@Name", name);
                        cmd.Parameters.AddWithValue("@Email", email);
                        cmd.Parameters.AddWithValue("@Phone", phone);
                        cmd.ExecuteNonQuery();
                    }
                    AuditLogger.Log("INSERT", $"Borrower Code: {code}", $"Added borrower {name}");
                    MessageBox.Show("Borrower registered successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    ClearBorrowerForm();
                    LoadBorrowers();
                }
                catch (Exception ex) { MessageBox.Show("Error adding borrower: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error); }
            }
        }

        private void btnUpdateBorrower_Click(object sender, EventArgs e)
        {
            if (selectedBorrowerID == 0)
            {
                MessageBox.Show("Please select a borrower from the list to update.", "Selection Required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string code = txtBorrowerCode.Text.Trim();
            string name = txtBorrowerName.Text.Trim();
            string email = txtBorrowerEmail.Text.Trim();
            string phone = txtBorrowerPhone.Text.Trim();

            if (string.IsNullOrWhiteSpace(code) || string.IsNullOrWhiteSpace(name) || string.IsNullOrWhiteSpace(email) || string.IsNullOrWhiteSpace(phone))
            {
                MessageBox.Show("Please fill in all borrower details.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!IsValidEmail(email))
            {
                MessageBox.Show("Please enter a valid email address.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (IsDuplicateValue("Borrowers", "BorrowerCode", code, "BorrowerID", selectedBorrowerID))
            {
                MessageBox.Show("Borrower Code is assigned to another person.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (IsDuplicateValue("Borrowers", "Email", email, "BorrowerID", selectedBorrowerID))
            {
                MessageBox.Show("Email address is assigned to another borrower.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (SqlConnection conn = DbConfig.GetConnection())
            {
                try
                {
                    conn.Open();
                    string query = "UPDATE Borrowers SET BorrowerCode=@Code, FullName=@Name, Email=@Email, Phone=@Phone WHERE BorrowerID=@ID";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@ID", selectedBorrowerID);
                        cmd.Parameters.AddWithValue("@Code", code);
                        cmd.Parameters.AddWithValue("@Name", name);
                        cmd.Parameters.AddWithValue("@Email", email);
                        cmd.Parameters.AddWithValue("@Phone", phone);
                        cmd.ExecuteNonQuery();
                    }
                    AuditLogger.Log("UPDATE", $"Borrower ID: {selectedBorrowerID}", $"Updated borrower {name}");
                    MessageBox.Show("Borrower updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    ClearBorrowerForm();
                    LoadBorrowers();
                }
                catch (Exception ex) { MessageBox.Show("Error updating borrower: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error); }
            }
        }

        private void btnDeleteBorrower_Click(object sender, EventArgs e)
        {
            if (selectedBorrowerID == 0)
            {
                MessageBox.Show("Please select a borrower from the list to delete.", "Selection Required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (MessageBox.Show("Are you sure you want to delete this borrower?", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;

            using (SqlConnection conn = DbConfig.GetConnection())
            {
                try
                {
                    conn.Open();

                    string checkTx = "SELECT COUNT(*) FROM BorrowTransactions WHERE BorrowerID = @ID AND Status = 'Borrowed'";
                    using (SqlCommand checkCmd = new SqlCommand(checkTx, conn))
                    {
                        checkCmd.Parameters.AddWithValue("@ID", selectedBorrowerID);
                        if (Convert.ToInt32(checkCmd.ExecuteScalar()) > 0)
                        {
                            MessageBox.Show("Cannot delete borrower while they have active borrowed items.", "Action Blocked", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                            return;
                        }
                    }

                    using (SqlCommand cmd = new SqlCommand("DELETE FROM Borrowers WHERE BorrowerID=@ID", conn))
                    {
                        cmd.Parameters.AddWithValue("@ID", selectedBorrowerID);
                        cmd.ExecuteNonQuery();
                    }
                    AuditLogger.Log("DELETE", $"Borrower ID: {selectedBorrowerID}", "Deleted borrower");
                    ClearBorrowerForm();
                    LoadBorrowers();
                }
                catch (Exception ex) { MessageBox.Show("Error deleting borrower: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error); }
            }
        }

        private void dgvBorrowers_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.RowIndex < dgvBorrowers.Rows.Count)
            {
                DataGridViewRow row = dgvBorrowers.Rows[e.RowIndex];
                if (row.Cells["BorrowerID"].Value != DBNull.Value)
                {
                    selectedBorrowerID = Convert.ToInt32(row.Cells["BorrowerID"].Value);
                    txtBorrowerCode.Text = row.Cells["Borrower Code"].Value?.ToString();
                    txtBorrowerName.Text = row.Cells["Full Name"].Value?.ToString();
                    txtBorrowerEmail.Text = row.Cells["Email Address"].Value?.ToString();
                    txtBorrowerPhone.Text = row.Cells["Phone Number"].Value?.ToString();
                }
            }
        }

        private void ClearBorrowerForm()
        {
            selectedBorrowerID = 0;
            txtBorrowerCode.Clear();
            txtBorrowerName.Clear();
            txtBorrowerEmail.Clear();
            txtBorrowerPhone.Clear();
        }

        #endregion

        #region Transactions View (With Multi-Item Borrowing Cart & Detail Expand Modal)

        private void BuildTransactionsPanel()
        {
            pnlTransactionsView = new Panel { Dock = DockStyle.Fill };

            Panel pnlInputs = new Panel { Location = new Point(0, 0), Size = new Size(330, 620), BackColor = Color.White, Padding = new Padding(12) };

            pnlInputs.Controls.Add(new Label { Text = "Borrower", Location = new Point(12, 10), AutoSize = true, Font = new Font("Segoe UI", 9f, FontStyle.Bold) });
            cmbTxBorrower = new ComboBox { Location = new Point(12, 30), Width = 300, DropDownStyle = ComboBoxStyle.DropDownList };

            // Stage Items Section
            Label lblItemSec = new Label { Text = "Select Item & Quantity:", Location = new Point(12, 60), AutoSize = true, Font = new Font("Segoe UI", 8.5f, FontStyle.Bold), ForeColor = Color.FromArgb(71, 85, 105) };
            cmbTxItem = new ComboBox { Location = new Point(12, 80), Width = 220, DropDownStyle = ComboBoxStyle.DropDownList };
            txtTxQty = new TextBox { Location = new Point(240, 80), Width = 72, Text = "1" };

            Button btnAddToCart = new Button
            {
                Text = "+ Add to Borrow List",
                Location = new Point(12, 110),
                Width = 300,
                Height = 30,
                BackColor = Color.FromArgb(51, 65, 85),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 8.5f, FontStyle.Bold),
                Cursor = Cursors.Hand
            };
            btnAddToCart.FlatAppearance.BorderSize = 0;
            btnAddToCart.Click += btnAddToCart_Click;

            // Staged Items Cart DataGridView
            Label lblCartTitle = new Label { Text = "Items To Borrow (Multi-Item Cart):", Location = new Point(12, 145), AutoSize = true, Font = new Font("Segoe UI", 8.5f, FontStyle.Bold) };
            dgvCart = new DataGridView
            {
                Location = new Point(12, 165),
                Size = new Size(300, 130),
                ReadOnly = true
            };
            StyleDataGridView(dgvCart);
            dgvCart.DataSource = dtCart;
            if (dgvCart.Columns["ItemID"] != null) dgvCart.Columns["ItemID"].Visible = false;
            if (dgvCart.Columns["AvailableStock"] != null) dgvCart.Columns["AvailableStock"].Visible = false;

            Button btnRemoveCartItem = new Button
            {
                Text = "- Remove Selected Item",
                Location = new Point(12, 300),
                Width = 300,
                Height = 26,
                BackColor = Color.FromArgb(226, 232, 240),
                ForeColor = Color.FromArgb(51, 65, 85),
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 8f, FontStyle.Bold),
                Cursor = Cursors.Hand
            };
            btnRemoveCartItem.FlatAppearance.BorderSize = 0;
            btnRemoveCartItem.Click += btnRemoveCartItem_Click;

            pnlInputs.Controls.Add(new Label { Text = "Due Date", Location = new Point(12, 335), AutoSize = true, Font = new Font("Segoe UI", 9f, FontStyle.Bold) });
            dtpTxDueDate = new DateTimePicker { Location = new Point(12, 355), Width = 300, Format = DateTimePickerFormat.Short };

            Button btnBorrow = CreateActionButton("Process Borrowing (Multi-Item)", Color.FromArgb(37, 99, 235), 390, btnBorrow_Click, 300);
            Button btnReturn = CreateActionButton("Return Selected Transaction", Color.FromArgb(16, 185, 129), 432, btnReturn_Click, 300);
            Button btnUpdate = CreateActionButton("Update Due Date", Color.FromArgb(217, 119, 6), 474, btnUpdateTransaction_Click, 300);
            Button btnDelete = CreateActionButton("Delete Record", Color.FromArgb(220, 38, 38), 516, btnDeleteTransaction_Click, 300);

            pnlInputs.Controls.AddRange(new Control[] { cmbTxBorrower, lblItemSec, cmbTxItem, txtTxQty, btnAddToCart, lblCartTitle, dgvCart, btnRemoveCartItem, dtpTxDueDate, btnBorrow, btnReturn, btnUpdate, btnDelete });

            Label lblSearch = new Label { Text = "Search Transactions:", Location = new Point(350, 12), AutoSize = true, Font = new Font("Segoe UI", 9.5f, FontStyle.Bold) };
            txtTxSearch = new TextBox { Location = new Point(490, 8), Width = 180, Font = new Font("Segoe UI", 9.5f) };
            txtTxSearch.TextChanged += (s, e) => LoadTransactions(txtTxSearch.Text.Trim());

            // Expand Items Detail Button
            btnExpandTxItems = new Button
            {
                Text = "🔍 View Itemized List",
                Location = new Point(680, 6),
                Width = 240,
                Height = 28,
                BackColor = Color.FromArgb(30, 41, 59),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 8.5f, FontStyle.Bold),
                Cursor = Cursors.Hand
            };
            btnExpandTxItems.FlatAppearance.BorderSize = 0;
            btnExpandTxItems.Click += (s, e) => ExpandSelectedTransactionDetails();

            dgvTransactions = new DataGridView { Location = new Point(350, 40), Size = new Size(570, 580), ReadOnly = true };
            StyleDataGridView(dgvTransactions);
            dgvTransactions.CellClick += dgvTransactions_CellClick;
            dgvTransactions.CellDoubleClick += (s, e) => ExpandSelectedTransactionDetails();
            dgvTransactions.CellFormatting += dgvTransactions_CellFormatting;

            pnlTransactionsView.Controls.AddRange(new Control[] { pnlInputs, lblSearch, txtTxSearch, btnExpandTxItems, dgvTransactions });
        }

        private void ExpandSelectedTransactionDetails()
        {
            if (selectedTransactionID == 0)
            {
                MessageBox.Show("Please select a transaction from the list first.", "Selection Required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            ShowTransactionItemsModal(selectedTransactionID);
        }

        private void ShowTransactionItemsModal(int transactionID)
        {
            Form modal = new Form
            {
                Text = $"Itemized List - Transaction #{transactionID}",
                Size = new Size(580, 360),
                StartPosition = FormStartPosition.CenterParent,
                FormBorderStyle = FormBorderStyle.FixedDialog,
                MaximizeBox = false,
                MinimizeBox = false,
                BackColor = Color.White
            };

            Label lblHeader = new Label
            {
                Text = $"Borrowed Items Breakdown (Transaction #{transactionID})",
                Font = new Font("Segoe UI", 11f, FontStyle.Bold),
                ForeColor = Color.FromArgb(30, 41, 59),
                Location = new Point(15, 15),
                AutoSize = true
            };

            DataGridView dgvDetails = new DataGridView
            {
                Location = new Point(15, 45),
                Size = new Size(535, 220),
                ReadOnly = true
            };
            StyleDataGridView(dgvDetails);

            Button btnClose = new Button
            {
                Text = "Close",
                Location = new Point(450, 275),
                Width = 100,
                Height = 32,
                BackColor = Color.FromArgb(100, 116, 139),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9f, FontStyle.Bold),
                Cursor = Cursors.Hand
            };
            btnClose.FlatAppearance.BorderSize = 0;
            btnClose.Click += (s, e) => modal.Close();

            using (SqlConnection conn = DbConfig.GetConnection())
            {
                try
                {
                    conn.Open();
                    string query = @"
                        SELECT 
                            i.ItemCode AS [Item Code],
                            i.ItemName AS [Item Name],
                            ISNULL(i.Category, 'Uncategorized') AS [Category],
                            d.Quantity AS [Qty Borrowed]
                        FROM BorrowDetails d
                        INNER JOIN Items i ON d.ItemID = i.ItemID
                        WHERE d.TransactionID = @TxID";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@TxID", transactionID);
                        SqlDataAdapter da = new SqlDataAdapter(cmd);
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        dgvDetails.DataSource = dt;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error loading transaction items: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

            modal.Controls.AddRange(new Control[] { lblHeader, dgvDetails, btnClose });
            modal.ShowDialog(this);
        }

        private void btnAddToCart_Click(object sender, EventArgs e)
        {
            if (cmbTxItem.SelectedValue == null)
            {
                MessageBox.Show("Please select an item to add.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!int.TryParse(txtTxQty.Text.Trim(), out int qty) || qty <= 0)
            {
                MessageBox.Show("Please enter a valid positive quantity.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int itemID = Convert.ToInt32(cmbTxItem.SelectedValue);

            using (SqlConnection conn = DbConfig.GetConnection())
            {
                try
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand("SELECT ItemCode, ItemName, AvailableQty FROM Items WHERE ItemID = @ID", conn);
                    cmd.Parameters.AddWithValue("@ID", itemID);
                    using (SqlDataReader r = cmd.ExecuteReader())
                    {
                        if (r.Read())
                        {
                            string code = r["ItemCode"].ToString();
                            string name = r["ItemName"].ToString();
                            int avail = Convert.ToInt32(r["AvailableQty"]);

                            // Check if item already exists in cart
                            DataRow existingRow = null;
                            foreach (DataRow row in dtCart.Rows)
                            {
                                if (Convert.ToInt32(row["ItemID"]) == itemID)
                                {
                                    existingRow = row;
                                    break;
                                }
                            }

                            int existingQtyInCart = existingRow != null ? Convert.ToInt32(existingRow["Quantity"]) : 0;
                            if ((existingQtyInCart + qty) > avail)
                            {
                                MessageBox.Show($"Cannot add. Total requested ({existingQtyInCart + qty}) exceeds available stock ({avail}).", "Stock Limit Exceeded", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                return;
                            }

                            if (existingRow != null)
                            {
                                existingRow["Quantity"] = existingQtyInCart + qty;
                            }
                            else
                            {
                                dtCart.Rows.Add(itemID, code, name, qty, avail);
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error adding item to cart: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnRemoveCartItem_Click(object sender, EventArgs e)
        {
            if (dgvCart.CurrentRow != null && dgvCart.CurrentRow.Index >= 0)
            {
                dgvCart.Rows.RemoveAt(dgvCart.CurrentRow.Index);
            }
        }

        private void ClearCart()
        {
            dtCart.Clear();
            txtTxQty.Text = "1";
        }

        private void LoadBorrowersDropdown()
        {
            using (SqlConnection conn = DbConfig.GetConnection())
            {
                try
                {
                    conn.Open();
                    SqlDataAdapter da = new SqlDataAdapter("SELECT BorrowerID, FullName + ' (' + BorrowerCode + ')' AS DisplayName FROM Borrowers ORDER BY FullName", conn);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    cmbTxBorrower.DataSource = dt;
                    cmbTxBorrower.DisplayMember = "DisplayName";
                    cmbTxBorrower.ValueMember = "BorrowerID";
                    cmbTxBorrower.SelectedIndex = -1;
                }
                catch { }
            }
        }

        private void LoadItemsDropdown()
        {
            using (SqlConnection conn = DbConfig.GetConnection())
            {
                try
                {
                    conn.Open();
                    SqlDataAdapter da = new SqlDataAdapter("SELECT ItemID, ItemName + ' (Avail: ' + CAST(AvailableQty AS VARCHAR) + ')' AS DisplayName FROM Items WHERE AvailableQty > 0 ORDER BY ItemName", conn);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    cmbTxItem.DataSource = dt;
                    cmbTxItem.DisplayMember = "DisplayName";
                    cmbTxItem.ValueMember = "ItemID";
                    cmbTxItem.SelectedIndex = -1;
                }
                catch { }
            }
        }

        private void LoadTransactions(string search = "")
        {
            using (SqlConnection conn = DbConfig.GetConnection())
            {
                try
                {
                    conn.Open();
                    string query = @"SELECT 
                                        t.TransactionID, 
                                        b.FullName AS [Borrower Name], 
                                        STUFF((
                                            SELECT ', ' + i.ItemName + ' (x' + CAST(d.Quantity AS VARCHAR) + ')'
                                            FROM BorrowDetails d
                                            INNER JOIN Items i ON d.ItemID = i.ItemID
                                            WHERE d.TransactionID = t.TransactionID
                                            FOR XML PATH('')
                                        ), 1, 2, '') AS [Items Summary],
                                        CONVERT(VARCHAR(10), t.BorrowDate, 120) AS [Borrow Date], 
                                        CONVERT(VARCHAR(10), t.DueDate, 120) AS [Due Date], 
                                        ISNULL(CONVERT(VARCHAR(10), t.ReturnDate, 120), 'Not Returned Yet') AS [Return Date], 
                                        t.Status AS [Status] 
                                    FROM BorrowTransactions t
                                    INNER JOIN Borrowers b ON t.BorrowerID = b.BorrowerID
                                    WHERE b.FullName LIKE @Search OR t.Status LIKE @Search
                                    ORDER BY t.TransactionID DESC";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@Search", $"%{search}%");
                        SqlDataAdapter da = new SqlDataAdapter(cmd);
                        DataTable dt = new DataTable();
                        da.Fill(dt);

                        dgvTransactions.DataSource = null;
                        dgvTransactions.AutoGenerateColumns = true;
                        dgvTransactions.Columns.Clear();
                        dgvTransactions.DataSource = dt;

                        if (dgvTransactions.Columns["TransactionID"] != null) dgvTransactions.Columns["TransactionID"].Visible = false;
                    }
                }
                catch (Exception ex) { MessageBox.Show("Error loading transactions: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error); }
            }
        }

        private void btnBorrow_Click(object sender, EventArgs e)
        {
            if (cmbTxBorrower.SelectedValue == null)
            {
                MessageBox.Show("Please select a borrower.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (dtCart.Rows.Count == 0)
            {
                MessageBox.Show("Please add at least one item to the borrow list.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (dtpTxDueDate.Value.Date < DateTime.Today)
            {
                MessageBox.Show("Due date cannot be set in the past.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int borrowerID = Convert.ToInt32(cmbTxBorrower.SelectedValue);

            using (SqlConnection conn = DbConfig.GetConnection())
            {
                conn.Open();
                SqlTransaction tx = conn.BeginTransaction();
                try
                {
                    // 1. Verify availability for all items in cart
                    foreach (DataRow row in dtCart.Rows)
                    {
                        int itemID = Convert.ToInt32(row["ItemID"]);
                        int qty = Convert.ToInt32(row["Quantity"]);

                        SqlCommand checkCmd = new SqlCommand("SELECT AvailableQty FROM Items WHERE ItemID=@ID", conn, tx);
                        checkCmd.Parameters.AddWithValue("@ID", itemID);
                        int avail = Convert.ToInt32(checkCmd.ExecuteScalar() ?? 0);

                        if (qty > avail)
                        {
                            MessageBox.Show($"Stock changed! Item '{row["ItemName"]}' only has {avail} available.", "Stock Insufficient", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            tx.Rollback();
                            return;
                        }
                    }

                    // 2. Insert Single Parent Transaction
                    string insTx = "INSERT INTO BorrowTransactions (BorrowerID, BorrowDate, DueDate, Status) VALUES (@BID, GETDATE(), @DueDate, 'Borrowed'); SELECT SCOPE_IDENTITY();";
                    SqlCommand cmdTx = new SqlCommand(insTx, conn, tx);
                    cmdTx.Parameters.AddWithValue("@BID", borrowerID);
                    cmdTx.Parameters.AddWithValue("@DueDate", dtpTxDueDate.Value);
                    int txID = Convert.ToInt32(cmdTx.ExecuteScalar());

                    // 3. Insert Details & Deduct Stock for each item
                    foreach (DataRow row in dtCart.Rows)
                    {
                        int itemID = Convert.ToInt32(row["ItemID"]);
                        int qty = Convert.ToInt32(row["Quantity"]);

                        SqlCommand cmdDetail = new SqlCommand("INSERT INTO BorrowDetails (TransactionID, ItemID, Quantity) VALUES (@TID, @IID, @Qty)", conn, tx);
                        cmdDetail.Parameters.AddWithValue("@TID", txID);
                        cmdDetail.Parameters.AddWithValue("@IID", itemID);
                        cmdDetail.Parameters.AddWithValue("@Qty", qty);
                        cmdDetail.ExecuteNonQuery();

                        SqlCommand cmdDeduct = new SqlCommand("UPDATE Items SET AvailableQty = AvailableQty - @Qty WHERE ItemID = @IID", conn, tx);
                        cmdDeduct.Parameters.AddWithValue("@Qty", qty);
                        cmdDeduct.Parameters.AddWithValue("@IID", itemID);
                        cmdDeduct.ExecuteNonQuery();
                    }

                    tx.Commit();
                    AuditLogger.Log("BORROW", $"Tx ID: {txID}", $"Borrowed {dtCart.Rows.Count} distinct item line(s)");
                    MessageBox.Show("Transaction processed successfully! Multiple items borrowed.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    ClearCart();
                    ClearTransactionForm();
                    LoadTransactions();
                    LoadItemsDropdown();
                }
                catch (Exception ex)
                {
                    tx.Rollback();
                    MessageBox.Show("Transaction error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            if (selectedTransactionID == 0)
            {
                MessageBox.Show("Please select a transaction from the table to return.", "Selection Required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (SqlConnection conn = DbConfig.GetConnection())
            {
                conn.Open();
                SqlTransaction tx = conn.BeginTransaction();
                try
                {
                    SqlCommand cmdCheck = new SqlCommand("SELECT Status FROM BorrowTransactions WHERE TransactionID = @TxID", conn, tx);
                    cmdCheck.Parameters.AddWithValue("@TxID", selectedTransactionID);
                    string status = cmdCheck.ExecuteScalar()?.ToString();

                    if (status == "Returned")
                    {
                        MessageBox.Show("This transaction has already been returned.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        tx.Rollback();
                        return;
                    }

                    // Update parent transaction status and return date
                    SqlCommand cmdUpd = new SqlCommand("UPDATE BorrowTransactions SET Status='Returned', ReturnDate=GETDATE() WHERE TransactionID=@TxID", conn, tx);
                    cmdUpd.Parameters.AddWithValue("@TxID", selectedTransactionID);
                    cmdUpd.ExecuteNonQuery();

                    // Restore stock for all items associated with this transaction
                    SqlCommand cmdGetItems = new SqlCommand("SELECT ItemID, Quantity FROM BorrowDetails WHERE TransactionID=@TxID", conn, tx);
                    cmdGetItems.Parameters.AddWithValue("@TxID", selectedTransactionID);

                    DataTable dtItems = new DataTable();
                    SqlDataAdapter da = new SqlDataAdapter(cmdGetItems);
                    da.Fill(dtItems);

                    foreach (DataRow r in dtItems.Rows)
                    {
                        int itemID = Convert.ToInt32(r["ItemID"]);
                        int qty = Convert.ToInt32(r["Quantity"]);

                        SqlCommand cmdRestore = new SqlCommand("UPDATE Items SET AvailableQty = AvailableQty + @Qty WHERE ItemID = @IID", conn, tx);
                        cmdRestore.Parameters.AddWithValue("@Qty", qty);
                        cmdRestore.Parameters.AddWithValue("@IID", itemID);
                        cmdRestore.ExecuteNonQuery();
                    }

                    tx.Commit();
                    AuditLogger.Log("RETURN", $"Tx ID: {selectedTransactionID}", "All items returned");
                    MessageBox.Show("All items in transaction returned successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    ClearTransactionForm();
                    LoadTransactions();
                    LoadItemsDropdown();
                }
                catch (Exception ex)
                {
                    tx.Rollback();
                    MessageBox.Show("Return error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnUpdateTransaction_Click(object sender, EventArgs e)
        {
            if (selectedTransactionID == 0)
            {
                MessageBox.Show("Please select a transaction from the table to update.", "Selection Required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (dtpTxDueDate.Value.Date < DateTime.Today)
            {
                MessageBox.Show("Due date cannot be set in the past.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (SqlConnection conn = DbConfig.GetConnection())
            {
                try
                {
                    conn.Open();
                    string query = "UPDATE BorrowTransactions SET DueDate = @DueDate WHERE TransactionID = @TxID";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@DueDate", dtpTxDueDate.Value);
                        cmd.Parameters.AddWithValue("@TxID", selectedTransactionID);
                        cmd.ExecuteNonQuery();
                    }
                    MessageBox.Show("Transaction due date updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    ClearTransactionForm();
                    LoadTransactions();
                }
                catch (Exception ex) { MessageBox.Show("Error updating transaction: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error); }
            }
        }

        private void btnDeleteTransaction_Click(object sender, EventArgs e)
        {
            if (selectedTransactionID == 0)
            {
                MessageBox.Show("Please select a transaction from the table to delete.", "Selection Required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (MessageBox.Show("Delete this transaction record?", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;

            using (SqlConnection conn = DbConfig.GetConnection())
            {
                conn.Open();
                SqlTransaction tx = conn.BeginTransaction();
                try
                {
                    SqlCommand cmdDelDetails = new SqlCommand("DELETE FROM BorrowDetails WHERE TransactionID=@TxID", conn, tx);
                    cmdDelDetails.Parameters.AddWithValue("@TxID", selectedTransactionID);
                    cmdDelDetails.ExecuteNonQuery();

                    SqlCommand cmdDelTx = new SqlCommand("DELETE FROM BorrowTransactions WHERE TransactionID=@TxID", conn, tx);
                    cmdDelTx.Parameters.AddWithValue("@TxID", selectedTransactionID);
                    cmdDelTx.ExecuteNonQuery();

                    tx.Commit();
                    MessageBox.Show("Transaction record deleted.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    ClearTransactionForm();
                    LoadTransactions();
                }
                catch (Exception ex)
                {
                    tx.Rollback();
                    MessageBox.Show("Error deleting transaction: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void dgvTransactions_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.RowIndex < dgvTransactions.Rows.Count)
            {
                DataGridViewRow row = dgvTransactions.Rows[e.RowIndex];
                if (row.Cells["TransactionID"].Value != DBNull.Value)
                {
                    selectedTransactionID = Convert.ToInt32(row.Cells["TransactionID"].Value);

                    if (DateTime.TryParse(row.Cells["Due Date"].Value?.ToString(), out DateTime dueDate))
                    {
                        if (dueDate >= dtpTxDueDate.MinDate && dueDate <= dtpTxDueDate.MaxDate)
                        {
                            dtpTxDueDate.Value = dueDate;
                        }
                    }
                }
            }
        }

        private void dgvTransactions_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (e.RowIndex >= 0 && e.RowIndex < dgvTransactions.Rows.Count)
            {
                DataGridViewRow row = dgvTransactions.Rows[e.RowIndex];
                if (row.Cells["Status"].Value?.ToString() == "Borrowed")
                {
                    if (DateTime.TryParse(row.Cells["Due Date"].Value?.ToString(), out DateTime dueDate))
                    {
                        int daysLeft = (dueDate.Date - DateTime.Today).Days;
                        if (daysLeft < 0) { e.CellStyle.BackColor = Color.LightCoral; e.CellStyle.ForeColor = Color.White; }
                        else if (daysLeft == 0) { e.CellStyle.BackColor = Color.Orange; e.CellStyle.ForeColor = Color.Black; }
                        else if (daysLeft <= 3) { e.CellStyle.BackColor = Color.Khaki; e.CellStyle.ForeColor = Color.Black; }
                    }
                }
            }
        }

        private void ClearTransactionForm()
        {
            selectedTransactionID = 0;
            cmbTxBorrower.SelectedIndex = -1;
            cmbTxItem.SelectedIndex = -1;
            dtpTxDueDate.Value = DateTime.Today.AddDays(7);
        }

        #endregion

        #region Borrower History & Penalty Tracker View (Enhanced Layout & Column Weights)

        private void BuildHistoryPanel()
        {
            pnlHistoryView = new Panel { Dock = DockStyle.Fill };

            // Top Borrower Selector Card
            Panel pnlSelect = new Panel
            {
                Location = new Point(0, 0),
                Size = new Size(920, 55),
                BackColor = Color.White
            };

            Label lblSelect = new Label
            {
                Text = "Select Borrower:",
                Font = new Font("Segoe UI", 10f, FontStyle.Bold),
                Location = new Point(15, 16),
                AutoSize = true
            };

            cmbHistoryBorrower = new ComboBox
            {
                Location = new Point(140, 13),
                Width = 350,
                Font = new Font("Segoe UI", 10f),
                DropDownStyle = ComboBoxStyle.DropDownList
            };
            cmbHistoryBorrower.SelectedIndexChanged += cmbHistoryBorrower_SelectedIndexChanged;

            lblHistoryStatus = new Label
            {
                Text = "STATUS: SELECT A BORROWER",
                Font = new Font("Segoe UI", 9.5f, FontStyle.Bold),
                ForeColor = Color.FromArgb(100, 116, 139),
                Location = new Point(505, 16),
                AutoSize = true
            };

            pnlSelect.Controls.AddRange(new Control[] { lblSelect, cmbHistoryBorrower, lblHistoryStatus });

            // Stat Cards for Selected Borrower
            Panel card1 = CreateStatCard("Total Borrows", "0", Color.FromArgb(37, 99, 235), 0, out lblHistTotalBorrows);
            card1.Top = 68; card1.Width = 215;

            Panel card2 = CreateStatCard("Active Items", "0", Color.FromArgb(16, 185, 129), 235, out lblHistActiveBorrows);
            card2.Top = 68; card2.Width = 215;

            Panel card3 = CreateStatCard("Active Overdue", "0", Color.FromArgb(220, 38, 38), 470, out lblHistOverdueBorrows);
            card3.Top = 68; card3.Width = 215;

            Panel card4 = CreateStatCard("Returned Late", "0", Color.FromArgb(217, 119, 6), 705, out lblHistLateReturns);
            card4.Top = 68; card4.Width = 215;

            // Details Grid
            Label lblGridTitle = new Label
            {
                Text = "Borrowing History & Penalty Evidence Log",
                Font = new Font("Segoe UI", 11f, FontStyle.Bold),
                ForeColor = Color.FromArgb(30, 41, 59),
                Location = new Point(0, 178),
                AutoSize = true
            };

            dgvBorrowerHistory = new DataGridView
            {
                Location = new Point(0, 208),
                Size = new Size(920, 412),
                ReadOnly = true
            };
            StyleDataGridView(dgvBorrowerHistory);
            dgvBorrowerHistory.CellFormatting += dgvBorrowerHistory_CellFormatting;

            pnlHistoryView.Controls.AddRange(new Control[] { pnlSelect, card1, card2, card3, card4, lblGridTitle, dgvBorrowerHistory });
        }

        private void LoadHistoryBorrowersDropdown()
        {
            using (SqlConnection conn = DbConfig.GetConnection())
            {
                try
                {
                    conn.Open();
                    SqlDataAdapter da = new SqlDataAdapter("SELECT BorrowerID, FullName + ' (' + BorrowerCode + ')' AS DisplayName FROM Borrowers ORDER BY FullName", conn);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    cmbHistoryBorrower.DataSource = dt;
                    cmbHistoryBorrower.DisplayMember = "DisplayName";
                    cmbHistoryBorrower.ValueMember = "BorrowerID";
                    cmbHistoryBorrower.SelectedIndex = -1;

                    lblHistoryStatus.Text = "STATUS: SELECT A BORROWER";
                    lblHistoryStatus.ForeColor = Color.FromArgb(100, 116, 139);
                    lblHistTotalBorrows.Text = "0";
                    lblHistActiveBorrows.Text = "0";
                    lblHistOverdueBorrows.Text = "0";
                    lblHistLateReturns.Text = "0";

                    dgvBorrowerHistory.DataSource = null;
                    dgvBorrowerHistory.Columns.Clear();
                }
                catch { }
            }
        }

        private void cmbHistoryBorrower_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbHistoryBorrower.SelectedValue == null || !(cmbHistoryBorrower.SelectedValue is int))
                return;

            int borrowerID = Convert.ToInt32(cmbHistoryBorrower.SelectedValue);

            using (SqlConnection conn = DbConfig.GetConnection())
            {
                try
                {
                    conn.Open();

                    // 1. Fetch Borrower Summary & Penalty Metrics
                    string summaryQuery = @"
                        SELECT 
                            COUNT(*) AS TotalBorrows,
                            ISNULL(SUM(CASE WHEN Status = 'Borrowed' THEN 1 ELSE 0 END), 0) AS ActiveBorrows,
                            ISNULL(SUM(CASE WHEN Status = 'Borrowed' AND CAST(DueDate AS DATE) < CAST(GETDATE() AS DATE) THEN 1 ELSE 0 END), 0) AS OverdueBorrows,
                            ISNULL(SUM(CASE WHEN Status = 'Returned' AND CAST(ReturnDate AS DATE) > CAST(DueDate AS DATE) THEN 1 ELSE 0 END), 0) AS LateReturns
                        FROM BorrowTransactions
                        WHERE BorrowerID = @BID";

                    int total = 0, active = 0, overdue = 0, late = 0;
                    using (SqlCommand cmd = new SqlCommand(summaryQuery, conn))
                    {
                        cmd.Parameters.AddWithValue("@BID", borrowerID);
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                total = Convert.ToInt32(reader["TotalBorrows"]);
                                active = Convert.ToInt32(reader["ActiveBorrows"]);
                                overdue = Convert.ToInt32(reader["OverdueBorrows"]);
                                late = Convert.ToInt32(reader["LateReturns"]);
                            }
                        }
                    }

                    lblHistTotalBorrows.Text = total.ToString();
                    lblHistActiveBorrows.Text = active.ToString();
                    lblHistOverdueBorrows.Text = overdue.ToString();
                    lblHistLateReturns.Text = late.ToString();

                    // Evaluate Penalty Status Banner
                    if (overdue > 0)
                    {
                        lblHistoryStatus.Text = $"FLAGGED: HAS {overdue} UNRETURNED OVERDUE ITEM(S)!";
                        lblHistoryStatus.ForeColor = Color.FromArgb(220, 38, 38); // Red
                    }
                    else if (late > 0)
                    {
                        lblHistoryStatus.Text = $"WARNING: HAS {late} PAST LATE RETURN RECORD(S)";
                        lblHistoryStatus.ForeColor = Color.FromArgb(217, 119, 6); // Orange
                    }
                    else
                    {
                        lblHistoryStatus.Text = "STATUS: GOOD STANDING";
                        lblHistoryStatus.ForeColor = Color.FromArgb(16, 185, 129); // Green
                    }

                    // 2. Load Itemized History Log with Explicit Return Date & Penalty Proof Evidence
                    string detailQuery = @"
                        SELECT 
                            t.TransactionID, 
                            i.ItemName AS [Item Name], 
                            d.Quantity AS [Qty], 
                            CONVERT(VARCHAR(10), t.BorrowDate, 120) AS [Borrow Date], 
                            CONVERT(VARCHAR(10), t.DueDate, 120) AS [Due Date], 
                            ISNULL(CONVERT(VARCHAR(10), t.ReturnDate, 120), 'Not Returned Yet') AS [Return Date], 
                            t.Status AS [Status],
                            CASE 
                                WHEN t.Status = 'Borrowed' AND CAST(t.DueDate AS DATE) < CAST(GETDATE() AS DATE) 
                                     THEN 'NOT RETURNED (OVERDUE by ' + CAST(DATEDIFF(day, t.DueDate, GETDATE()) AS VARCHAR) + ' days)'
                                WHEN t.Status = 'Returned' AND CAST(t.ReturnDate AS DATE) > CAST(t.DueDate AS DATE) 
                                     THEN 'RETURNED LATE on ' + CONVERT(VARCHAR(10), t.ReturnDate, 120) + ' (' + CAST(DATEDIFF(day, t.DueDate, t.ReturnDate) AS VARCHAR) + ' days late)'
                                WHEN t.Status = 'Returned' 
                                     THEN 'Returned On Time on ' + CONVERT(VARCHAR(10), t.ReturnDate, 120)
                                ELSE 'Active / Not Returned (On Schedule)'
                            END AS [Return Proof & Penalty Note]
                        FROM BorrowTransactions t
                        INNER JOIN BorrowDetails d ON t.TransactionID = d.TransactionID
                        INNER JOIN Items i ON d.ItemID = i.ItemID
                        WHERE t.BorrowerID = @BID
                        ORDER BY t.TransactionID DESC";

                    using (SqlCommand cmdDetail = new SqlCommand(detailQuery, conn))
                    {
                        cmdDetail.Parameters.AddWithValue("@BID", borrowerID);
                        SqlDataAdapter da = new SqlDataAdapter(cmdDetail);
                        DataTable dt = new DataTable();
                        da.Fill(dt);

                        // Clear designer columns and auto-bind all 7 columns dynamically
                        dgvBorrowerHistory.DataSource = null;
                        dgvBorrowerHistory.AutoGenerateColumns = true;
                        dgvBorrowerHistory.Columns.Clear();
                        dgvBorrowerHistory.DataSource = dt;

                        if (dgvBorrowerHistory.Columns["TransactionID"] != null)
                            dgvBorrowerHistory.Columns["TransactionID"].Visible = false;

                        // Configure weighted auto-sizing so long text columns fill cleanly
                        if (dgvBorrowerHistory.Columns["Item Name"] != null) dgvBorrowerHistory.Columns["Item Name"].FillWeight = 110;
                        if (dgvBorrowerHistory.Columns["Qty"] != null) dgvBorrowerHistory.Columns["Qty"].FillWeight = 40;
                        if (dgvBorrowerHistory.Columns["Borrow Date"] != null) dgvBorrowerHistory.Columns["Borrow Date"].FillWeight = 90;
                        if (dgvBorrowerHistory.Columns["Due Date"] != null) dgvBorrowerHistory.Columns["Due Date"].FillWeight = 90;
                        if (dgvBorrowerHistory.Columns["Return Date"] != null) dgvBorrowerHistory.Columns["Return Date"].FillWeight = 100;
                        if (dgvBorrowerHistory.Columns["Status"] != null) dgvBorrowerHistory.Columns["Status"].FillWeight = 70;
                        if (dgvBorrowerHistory.Columns["Return Proof & Penalty Note"] != null) dgvBorrowerHistory.Columns["Return Proof & Penalty Note"].FillWeight = 200;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error loading borrower history: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void dgvBorrowerHistory_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (e.RowIndex >= 0 && e.RowIndex < dgvBorrowerHistory.Rows.Count)
            {
                DataGridViewRow row = dgvBorrowerHistory.Rows[e.RowIndex];

                if (row.Cells["Return Proof & Penalty Note"] != null)
                {
                    string proofNote = row.Cells["Return Proof & Penalty Note"].Value?.ToString();

                    if (!string.IsNullOrEmpty(proofNote))
                    {
                        if (proofNote.StartsWith("NOT RETURNED (OVERDUE"))
                        {
                            e.CellStyle.BackColor = Color.FromArgb(254, 226, 226); // Soft Red
                            e.CellStyle.ForeColor = Color.FromArgb(153, 27, 27); // Dark Red
                            e.CellStyle.Font = new Font("Segoe UI", 9f, FontStyle.Bold);
                        }
                        else if (proofNote.StartsWith("RETURNED LATE"))
                        {
                            e.CellStyle.BackColor = ColorTranslator.FromHtml("#FFF3CD"); // Soft Amber Yellow
                            e.CellStyle.ForeColor = Color.FromArgb(133, 100, 4); // Dark Amber
                            e.CellStyle.Font = new Font("Segoe UI", 9f, FontStyle.Bold);
                        }
                        else if (proofNote.StartsWith("Returned On Time"))
                        {
                            e.CellStyle.BackColor = Color.FromArgb(240, 253, 244); // Soft Green
                            e.CellStyle.ForeColor = Color.FromArgb(22, 101, 52);
                        }
                    }
                }
            }
        }

        #endregion

        #region Helpers & Common Styling

        private Button CreateActionButton(string text, Color backColor, int top, EventHandler onClick, int width = 250)
        {
            Button btn = new Button
            {
                Text = text,
                Top = top,
                Left = 12,
                Width = width,
                Height = 36,
                FlatStyle = FlatStyle.Flat,
                BackColor = backColor,
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 9f, FontStyle.Bold),
                Cursor = Cursors.Hand
            };
            btn.FlatAppearance.BorderSize = 0;
            btn.Click += onClick;
            return btn;
        }

        private void StyleDataGridView(DataGridView dgv)
        {
            dgv.BackgroundColor = Color.White;
            dgv.BorderStyle = BorderStyle.None;
            dgv.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            dgv.GridColor = Color.FromArgb(230, 235, 240);
            dgv.EnableHeadersVisualStyles = false;
            dgv.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dgv.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(30, 41, 59);
            dgv.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dgv.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 9.5f, FontStyle.Bold);
            dgv.ColumnHeadersHeight = 38;
            dgv.DefaultCellStyle.Font = new Font("Segoe UI", 9f);
            dgv.DefaultCellStyle.ForeColor = Color.FromArgb(15, 23, 42);
            dgv.DefaultCellStyle.SelectionBackColor = Color.FromArgb(224, 231, 255);
            dgv.DefaultCellStyle.SelectionForeColor = Color.FromArgb(30, 58, 138);
            dgv.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(248, 250, 252);
            dgv.RowTemplate.Height = 32;
            dgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgv.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgv.MultiSelect = false;
        }

        #endregion
    }
}