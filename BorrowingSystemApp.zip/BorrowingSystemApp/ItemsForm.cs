﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace BorrowingSystemApp
{
    public partial class ItemsForm : Form
    {
        int selectedItemID = 0;

        public ItemsForm()
        {
            InitializeComponent();

            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.StartPosition = FormStartPosition.CenterScreen;

            // Safe Event Handlers Wiring
            WireUpEvents();
        }

        private void WireUpEvents()
        {
            if (Controls.Find("btnAdd", true).Length > 0 && btnAdd != null) { btnAdd.Click -= btnAdd_Click; btnAdd.Click += btnAdd_Click; }
            if (Controls.Find("btnUpdate", true).Length > 0 && btnUpdate != null) { btnUpdate.Click -= btnUpdate_Click; btnUpdate.Click += btnUpdate_Click; }
            if (Controls.Find("btnDelete", true).Length > 0 && btnDelete != null) { btnDelete.Click -= btnDelete_Click; btnDelete.Click += btnDelete_Click; }
            if (Controls.Find("btnClear", true).Length > 0 && btnClear != null) { btnClear.Click -= btnClear_Click; btnClear.Click += btnClear_Click; }
            if (Controls.Find("dgvItems", true).Length > 0 && dgvItems != null) { dgvItems.CellClick -= dgvItems_CellClick; dgvItems.CellClick += dgvItems_CellClick; }
            if (Controls.Find("txtSearch", true).Length > 0 && txtSearch != null) { txtSearch.TextChanged -= txtSearch_TextChanged; txtSearch.TextChanged += txtSearch_TextChanged; }
        }

        private void ItemsForm_Load(object sender, EventArgs e)
        {
            lblCurrentUser.Text = $"Logged in as: {UserSession.Username}";
            this.Text += $" | Active User: {UserSession.Username}";
            if (dgvItems != null) dgvItems.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

            // Apply Modern UI Visuals Automatically
            ApplyModernDesign();

            LoadCategoriesDropdown();
            LoadItems();
            AutoGenerateItemCode();
        }

        private void LoadCategoriesDropdown()
        {
            using (SqlConnection conn = new SqlConnection(DbConfig.ConnectionString))
            {
                try
                {
                    conn.Open();
                    string query = "SELECT DISTINCT Category FROM Items WHERE Category IS NOT NULL AND Category <> '' ORDER BY Category";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    SqlDataReader reader = cmd.ExecuteReader();

                    Control[] cmbCat = Controls.Find("cmbCategory", true);
                    if (cmbCat.Length > 0 && cmbCat[0] is ComboBox cb)
                    {
                        cb.Items.Clear();
                        while (reader.Read())
                        {
                            cb.Items.Add(reader["Category"].ToString());
                        }
                        cb.DropDownStyle = ComboBoxStyle.DropDown;
                    }
                }
                catch
                {
                    // Fallback silently if cmbCategory is not found
                }
            }
        }

        private void LoadItems(string search = "")
        {
            using (SqlConnection conn = new SqlConnection(DbConfig.ConnectionString))
            {
                try
                {
                    conn.Open();
                    string query = @"SELECT ItemID, ItemCode AS [Item Code], ItemName AS [Item Name], Category, TotalQty AS [Total Qty], AvailableQty AS [Available Qty] 
                                    FROM Items 
                                    WHERE ItemName LIKE @Search OR ItemCode LIKE @Search OR Category LIKE @Search
                                    ORDER BY ItemID DESC";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@Search", $"%{search}%");
                        SqlDataAdapter da = new SqlDataAdapter(cmd);
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        if (dgvItems != null)
                        {
                            dgvItems.DataSource = dt;
                            if (dgvItems.Columns["ItemID"] != null)
                                dgvItems.Columns["ItemID"].Visible = false;
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error loading items: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            if (txtSearch != null)
                LoadItems(txtSearch.Text.Trim());
        }

        private void AutoGenerateItemCode()
        {
            using (SqlConnection conn = new SqlConnection(DbConfig.ConnectionString))
            {
                try
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand("SELECT ISNULL(MAX(ItemID), 0) + 1 FROM Items", conn);
                    int nextId = Convert.ToInt32(cmd.ExecuteScalar());
                    if (txtItemCode != null) txtItemCode.Text = "ITM-" + nextId.ToString("D4");
                }
                catch
                {
                    if (txtItemCode != null) txtItemCode.Text = "ITM-0001";
                }
            }
        }

        private string GetCategoryText()
        {
            Control[] cmbCat = Controls.Find("cmbCategory", true);
            if (cmbCat.Length > 0 && cmbCat[0] is ComboBox cb) return cb.Text.Trim();

            Control[] txtCat = Controls.Find("txtCategory", true);
            if (txtCat.Length > 0 && txtCat[0] is TextBox tb) return tb.Text.Trim();

            return "";
        }

        private void SetCategoryText(string val)
        {
            Control[] cmbCat = Controls.Find("cmbCategory", true);
            if (cmbCat.Length > 0 && cmbCat[0] is ComboBox cb) { cb.Text = val; return; }

            Control[] txtCat = Controls.Find("txtCategory", true);
            if (txtCat.Length > 0 && txtCat[0] is TextBox tb) { tb.Text = val; return; }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            string code = txtItemCode != null ? txtItemCode.Text.Trim() : "";
            string name = txtItemName != null ? txtItemName.Text.Trim() : "";
            string totalStr = txtTotalQty != null ? txtTotalQty.Text.Trim() : "";
            string availStr = txtAvailableQty != null ? txtAvailableQty.Text.Trim() : "";
            string category = GetCategoryText();

            // 1. Mandatory Input Validation
            if (string.IsNullOrWhiteSpace(code))
            {
                MessageBox.Show("Please enter or generate an Item Code.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                if (txtItemCode != null) txtItemCode.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(name))
            {
                MessageBox.Show("Please enter an Item Name.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                if (txtItemName != null) txtItemName.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(totalStr) || !int.TryParse(totalStr, out int totalQty) || totalQty < 0)
            {
                MessageBox.Show("Please enter a valid non-negative number for Total Quantity.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                if (txtTotalQty != null) txtTotalQty.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(availStr) || !int.TryParse(availStr, out int availQty) || availQty < 0)
            {
                MessageBox.Show("Please enter a valid non-negative number for Available Quantity.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                if (txtAvailableQty != null) txtAvailableQty.Focus();
                return;
            }

            if (availQty > totalQty)
            {
                MessageBox.Show("Available Quantity cannot exceed Total Quantity.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                if (txtAvailableQty != null) txtAvailableQty.Focus();
                return;
            }

            using (SqlConnection conn = new SqlConnection(DbConfig.ConnectionString))
            {
                try
                {
                    conn.Open();

                    // 2. Check for Duplicate Item Code
                    string checkQuery = "SELECT COUNT(*) FROM Items WHERE ItemCode = @Code";
                    using (SqlCommand checkCmd = new SqlCommand(checkQuery, conn))
                    {
                        checkCmd.Parameters.AddWithValue("@Code", code);
                        int exists = (int)checkCmd.ExecuteScalar();
                        if (exists > 0)
                        {
                            MessageBox.Show("An item with this Item Code already exists. Please use a unique code.", "Duplicate Code Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }
                    }

                    // 3. Database Insertion
                    string query = "INSERT INTO Items (ItemCode, ItemName, Category, TotalQty, AvailableQty) VALUES (@Code, @Name, @Category, @Total, @Available)";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@Code", code);
                        cmd.Parameters.AddWithValue("@Name", name);
                        cmd.Parameters.AddWithValue("@Category", string.IsNullOrWhiteSpace(category) ? (object)DBNull.Value : category);
                        cmd.Parameters.AddWithValue("@Total", totalQty);
                        cmd.Parameters.AddWithValue("@Available", availQty);
                        cmd.ExecuteNonQuery();
                    }

                    // 4. Audit Log
                    AuditLogger.Log("INSERT", $"Item Code: {code}", $"Added item '{name}' with Total Qty: {totalQty}, Available Qty: {availQty}");

                    MessageBox.Show("Item added successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    ClearForm();
                    LoadCategoriesDropdown();
                    LoadItems();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error adding item: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (selectedItemID == 0)
            {
                MessageBox.Show("Please select an item from the table first.", "Selection Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string code = txtItemCode != null ? txtItemCode.Text.Trim() : "";
            string name = txtItemName != null ? txtItemName.Text.Trim() : "";
            string totalStr = txtTotalQty != null ? txtTotalQty.Text.Trim() : "";
            string availStr = txtAvailableQty != null ? txtAvailableQty.Text.Trim() : "";
            string category = GetCategoryText();

            // Mandatory Field Checks
            if (string.IsNullOrWhiteSpace(code))
            {
                MessageBox.Show("Item Code cannot be empty.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (string.IsNullOrWhiteSpace(name))
            {
                MessageBox.Show("Item Name cannot be empty.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (string.IsNullOrWhiteSpace(totalStr) || !int.TryParse(totalStr, out int totalQty) || totalQty < 0)
            {
                MessageBox.Show("Please enter a valid non-negative number for Total Quantity.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (string.IsNullOrWhiteSpace(availStr) || !int.TryParse(availStr, out int availQty) || availQty < 0)
            {
                MessageBox.Show("Please enter a valid non-negative number for Available Quantity.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (availQty > totalQty)
            {
                MessageBox.Show("Available Quantity cannot exceed Total Quantity.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Update Confirmation Dialog
            DialogResult confirm = MessageBox.Show("Are you sure you want to update this item's details?", "Confirm Update", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (confirm != DialogResult.Yes) return;

            using (SqlConnection conn = new SqlConnection(DbConfig.ConnectionString))
            {
                try
                {
                    conn.Open();

                    // Check duplicate code against other items
                    string checkQuery = "SELECT COUNT(*) FROM Items WHERE ItemCode = @Code AND ItemID <> @ID";
                    using (SqlCommand checkCmd = new SqlCommand(checkQuery, conn))
                    {
                        checkCmd.Parameters.AddWithValue("@Code", code);
                        checkCmd.Parameters.AddWithValue("@ID", selectedItemID);
                        int exists = (int)checkCmd.ExecuteScalar();
                        if (exists > 0)
                        {
                            MessageBox.Show("This Item Code is already assigned to another item.", "Duplicate Code Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }
                    }

                    string query = "UPDATE Items SET ItemCode=@Code, ItemName=@Name, Category=@Category, TotalQty=@Total, AvailableQty=@Available WHERE ItemID=@ID";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@ID", selectedItemID);
                        cmd.Parameters.AddWithValue("@Code", code);
                        cmd.Parameters.AddWithValue("@Name", name);
                        cmd.Parameters.AddWithValue("@Category", string.IsNullOrWhiteSpace(category) ? (object)DBNull.Value : category);
                        cmd.Parameters.AddWithValue("@Total", totalQty);
                        cmd.Parameters.AddWithValue("@Available", availQty);
                        cmd.ExecuteNonQuery();
                    }

                    // Write to Audit Log
                    AuditLogger.Log("UPDATE", $"Item ID: {selectedItemID}", $"Updated item '{name}' ({code})");

                    MessageBox.Show("Item updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    ClearForm();
                    LoadCategoriesDropdown();
                    LoadItems();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error updating item: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (selectedItemID == 0)
            {
                MessageBox.Show("Please select an item from the table first.", "Selection Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DialogResult confirm = MessageBox.Show("Are you sure you want to delete this item?", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (confirm != DialogResult.Yes) return;

            using (SqlConnection conn = new SqlConnection(DbConfig.ConnectionString))
            {
                try
                {
                    conn.Open();
                    string query = "DELETE FROM Items WHERE ItemID=@ID";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@ID", selectedItemID);
                        cmd.ExecuteNonQuery();
                    }

                    // Write to Audit Log
                    AuditLogger.Log("DELETE", $"Item ID: {selectedItemID}", $"Deleted item: {txtItemName?.Text.Trim()}");

                    MessageBox.Show("Item deleted successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    ClearForm();
                    LoadCategoriesDropdown();
                    LoadItems();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error deleting item: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void dgvItems_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && dgvItems != null)
            {
                DataGridViewRow row = dgvItems.Rows[e.RowIndex];
                selectedItemID = Convert.ToInt32(row.Cells["ItemID"].Value);
                if (txtItemCode != null) txtItemCode.Text = row.Cells["Item Code"].Value?.ToString() ?? "";
                if (txtItemName != null) txtItemName.Text = row.Cells["Item Name"].Value?.ToString() ?? "";
                SetCategoryText(row.Cells["Category"].Value?.ToString() ?? "");

                int totalQty = Convert.ToInt32(row.Cells["Total Qty"].Value ?? 0);
                int availQty = Convert.ToInt32(row.Cells["Available Qty"].Value ?? 0);

                if (txtTotalQty != null) txtTotalQty.Text = totalQty.ToString();
                if (txtAvailableQty != null) txtAvailableQty.Text = availQty.ToString();
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearForm();
        }

        private void ClearForm()
        {
            selectedItemID = 0;
            if (txtItemName != null) txtItemName.Clear();
            SetCategoryText("");
            if (txtTotalQty != null) txtTotalQty.Clear();
            if (txtAvailableQty != null) txtAvailableQty.Clear();
            AutoGenerateItemCode();
        }

        #region Modern UI Styling

        private void ApplyModernDesign()
        {
            // Form Level Styling
            this.BackColor = Color.FromArgb(244, 246, 249);
            this.Font = new Font("Segoe UI", 9.5f, FontStyle.Regular);

            // Header Panel Styling (if named pnlHeader)
            Control[] headers = Controls.Find("pnlHeader", true);
            if (headers.Length > 0)
            {
                headers[0].BackColor = Color.FromArgb(30, 41, 59);
            }

            // Button Styling
            Control[] btnAddArr = Controls.Find("btnAdd", true);
            if (btnAddArr.Length > 0 && btnAddArr[0] is Button btnAddCtrl) StyleButton(btnAddCtrl, Color.FromArgb(37, 99, 235));
            else if (btnAdd != null) StyleButton(btnAdd, Color.FromArgb(37, 99, 235));

            Control[] btnUpdateArr = Controls.Find("btnUpdate", true);
            if (btnUpdateArr.Length > 0 && btnUpdateArr[0] is Button btnUpdateCtrl) StyleButton(btnUpdateCtrl, Color.FromArgb(217, 119, 6));
            else if (btnUpdate != null) StyleButton(btnUpdate, Color.FromArgb(217, 119, 6));

            Control[] btnDeleteArr = Controls.Find("btnDelete", true);
            if (btnDeleteArr.Length > 0 && btnDeleteArr[0] is Button btnDeleteCtrl) StyleButton(btnDeleteCtrl, Color.FromArgb(220, 38, 38));
            else if (btnDelete != null) StyleButton(btnDelete, Color.FromArgb(220, 38, 38));

            Control[] btnClearArr = Controls.Find("btnClear", true);
            if (btnClearArr.Length > 0 && btnClearArr[0] is Button btnClearCtrl) StyleButton(btnClearCtrl, Color.FromArgb(100, 116, 139));
            else if (btnClear != null) StyleButton(btnClear, Color.FromArgb(100, 116, 139));

            // DataGridView Table Refresh
            if (dgvItems != null)
            {
                StyleDataGridView(dgvItems);
            }
        }

        private void StyleButton(Button btn, Color backColor)
        {
            if (btn == null) return;

            btn.FlatStyle = FlatStyle.Flat;
            btn.FlatAppearance.BorderSize = 0;
            btn.BackColor = backColor;
            btn.ForeColor = Color.White;
            btn.Font = new Font("Segoe UI", 9.0f, FontStyle.Bold);
            btn.Cursor = Cursors.Hand;
            btn.Height = 36;
        }

        private void StyleDataGridView(DataGridView dgv)
        {
            if (dgv == null) return;

            // Background & Grid Lines
            dgv.BackgroundColor = Color.White;
            dgv.BorderStyle = BorderStyle.None;
            dgv.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            dgv.GridColor = Color.FromArgb(230, 235, 240);

            // Header Row
            dgv.EnableHeadersVisualStyles = false;
            dgv.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dgv.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(30, 41, 59); // Dark Navy
            dgv.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dgv.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 9.5f, FontStyle.Bold);
            dgv.ColumnHeadersHeight = 38;

            // Data Rows
            dgv.DefaultCellStyle.Font = new Font("Segoe UI", 9.5f, FontStyle.Regular);
            dgv.DefaultCellStyle.ForeColor = Color.FromArgb(15, 23, 42);
            dgv.DefaultCellStyle.SelectionBackColor = Color.FromArgb(224, 231, 255); // Soft Indigo
            dgv.DefaultCellStyle.SelectionForeColor = Color.FromArgb(30, 58, 138);
            dgv.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(248, 250, 252);
            dgv.RowTemplate.Height = 34;

            // Layout Settings
            dgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgv.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgv.MultiSelect = false;
        }

        #endregion
    }
}