﻿using System;
using System.Windows.Forms;

namespace BorrowingSystemApp
{
    public partial class MainDashboard : Form
    {
        public MainDashboard()
        {
            InitializeComponent();
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.StartPosition = FormStartPosition.CenterScreen;

            // Ensures every button responds even if MainDashboard.Designer.cs lacks bindings
            btnBorrowers.Click -= btnBorrowers_Click;
            btnBorrowers.Click += btnBorrowers_Click;

            btnItems.Click -= btnItems_Click;
            btnItems.Click += btnItems_Click;

            btnTransactions.Click -= btnTransactions_Click;
            btnTransactions.Click += btnTransactions_Click;

            btnLogout.Click -= btnLogout_Click;
            btnLogout.Click += btnLogout_Click;
        }

        private void MainDashboard_Load(object sender, EventArgs e)
        {
            if (UserSession.UserID == 0)
            {
                MessageBox.Show("Please log in first.", "Access Denied", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                this.Close();
                return;
            }

            this.Text = $"Dashboard - Logged in as: {UserSession.FullName} ({UserSession.Username})";
        }

        private void btnItems_Click(object sender, EventArgs e)
        {
            ItemsForm itemsForm = new ItemsForm();
            itemsForm.ShowDialog();
        }

        private void btnBorrowers_Click(object sender, EventArgs e)
        {
            BorrowersForm borrowersForm = new BorrowersForm();
            borrowersForm.ShowDialog();
        }

        private void btnTransactions_Click(object sender, EventArgs e)
        {
            TransactionForm transForm = new TransactionForm();
            transForm.ShowDialog();
        }

        // Empty handler overrides the designer shortcut that was causing double-openings
        private void btnTransactions_Click_1(object sender, EventArgs e)
        {
            // Left intentionally blank
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            UserSession.ClearSession();
            this.Hide();
            Form1 login = new Form1();
            login.ShowDialog();
            this.Close();
        }
    }
}