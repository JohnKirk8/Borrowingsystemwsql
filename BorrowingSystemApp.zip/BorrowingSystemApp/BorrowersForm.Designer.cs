﻿namespace BorrowingSystemApp
{
    partial class BorrowersForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BorrowersForm));
            txtBorrowerCode = new TextBox();
            txtFullName = new TextBox();
            txtEmail = new TextBox();
            txtPhone = new TextBox();
            btnAdd = new Button();
            btnUpdate = new Button();
            btnDelete = new Button();
            btnClear = new Button();
            dgvBorrowers = new DataGridView();
            dgvItems = new Label();
            txtSearch = new TextBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            panel1 = new Panel();
            label5 = new Label();
            pictureBox1 = new PictureBox();
            lblCurrentUser = new Label();
            ((System.ComponentModel.ISupportInitialize)dgvBorrowers).BeginInit();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // txtBorrowerCode
            // 
            txtBorrowerCode.Location = new Point(204, 152);
            txtBorrowerCode.Margin = new Padding(4, 5, 4, 5);
            txtBorrowerCode.Name = "txtBorrowerCode";
            txtBorrowerCode.Size = new Size(132, 27);
            txtBorrowerCode.TabIndex = 0;
            // 
            // txtFullName
            // 
            txtFullName.Location = new Point(204, 208);
            txtFullName.Margin = new Padding(4, 5, 4, 5);
            txtFullName.Name = "txtFullName";
            txtFullName.Size = new Size(132, 27);
            txtFullName.TabIndex = 1;
            // 
            // txtEmail
            // 
            txtEmail.Location = new Point(204, 263);
            txtEmail.Margin = new Padding(4, 5, 4, 5);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(132, 27);
            txtEmail.TabIndex = 2;
            // 
            // txtPhone
            // 
            txtPhone.Location = new Point(204, 317);
            txtPhone.Margin = new Padding(4, 5, 4, 5);
            txtPhone.Name = "txtPhone";
            txtPhone.Size = new Size(132, 27);
            txtPhone.TabIndex = 3;
            // 
            // btnAdd
            // 
            btnAdd.Location = new Point(31, 547);
            btnAdd.Margin = new Padding(4, 5, 4, 5);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(100, 35);
            btnAdd.TabIndex = 4;
            btnAdd.Text = "Add";
            btnAdd.UseVisualStyleBackColor = true;
            // 
            // btnUpdate
            // 
            btnUpdate.Location = new Point(139, 547);
            btnUpdate.Margin = new Padding(4, 5, 4, 5);
            btnUpdate.Name = "btnUpdate";
            btnUpdate.Size = new Size(100, 35);
            btnUpdate.TabIndex = 5;
            btnUpdate.Text = "Update";
            btnUpdate.UseVisualStyleBackColor = true;
            // 
            // btnDelete
            // 
            btnDelete.Location = new Point(247, 547);
            btnDelete.Margin = new Padding(4, 5, 4, 5);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(100, 35);
            btnDelete.TabIndex = 6;
            btnDelete.Text = "Delete";
            btnDelete.UseVisualStyleBackColor = true;
            // 
            // btnClear
            // 
            btnClear.Location = new Point(355, 547);
            btnClear.Margin = new Padding(4, 5, 4, 5);
            btnClear.Name = "btnClear";
            btnClear.Size = new Size(100, 35);
            btnClear.TabIndex = 7;
            btnClear.Text = "Clear";
            btnClear.UseVisualStyleBackColor = true;
            // 
            // dgvBorrowers
            // 
            dgvBorrowers.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvBorrowers.Location = new Point(393, 168);
            dgvBorrowers.Margin = new Padding(4, 5, 4, 5);
            dgvBorrowers.Name = "dgvBorrowers";
            dgvBorrowers.RowHeadersWidth = 51;
            dgvBorrowers.Size = new Size(661, 231);
            dgvBorrowers.TabIndex = 8;
            dgvBorrowers.CellClick += dgvBorrowers_CellClick;
            // 
            // dgvItems
            // 
            dgvItems.AutoSize = true;
            dgvItems.Location = new Point(393, 137);
            dgvItems.Margin = new Padding(4, 0, 4, 0);
            dgvItems.Name = "dgvItems";
            dgvItems.Size = new Size(56, 20);
            dgvItems.TabIndex = 9;
            dgvItems.Text = "Search:";
            // 
            // txtSearch
            // 
            txtSearch.Location = new Point(460, 132);
            txtSearch.Margin = new Padding(4, 5, 4, 5);
            txtSearch.Name = "txtSearch";
            txtSearch.Size = new Size(252, 27);
            txtSearch.TabIndex = 10;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(55, 155);
            label1.Name = "label1";
            label1.Size = new Size(76, 20);
            label1.TabIndex = 11;
            label1.Text = "Item code";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(55, 211);
            label2.Name = "label2";
            label2.Size = new Size(120, 20);
            label2.TabIndex = 12;
            label2.Text = "Borrower's name";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(55, 270);
            label3.Name = "label3";
            label3.Size = new Size(120, 20);
            label3.TabIndex = 13;
            label3.Text = "Borrower's email";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(55, 324);
            label4.Name = "label4";
            label4.Size = new Size(105, 20);
            label4.TabIndex = 14;
            label4.Text = "Phone number";
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(30, 41, 59);
            panel1.Controls.Add(lblCurrentUser);
            panel1.Controls.Add(label5);
            panel1.Controls.Add(pictureBox1);
            panel1.Location = new Point(-8, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1075, 57);
            panel1.TabIndex = 20;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 16F);
            label5.ForeColor = SystemColors.ButtonHighlight;
            label5.Location = new Point(98, 9);
            label5.Name = "label5";
            label5.Size = new Size(246, 37);
            label5.TabIndex = 21;
            label5.Text = "Manage Borrower's";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(20, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(71, 67);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 21;
            pictureBox1.TabStop = false;
            // 
            // lblCurrentUser
            // 
            lblCurrentUser.AutoSize = true;
            lblCurrentUser.BackColor = SystemColors.ButtonHighlight;
            lblCurrentUser.Location = new Point(894, 23);
            lblCurrentUser.Name = "lblCurrentUser";
            lblCurrentUser.Size = new Size(137, 20);
            lblCurrentUser.TabIndex = 22;
            lblCurrentUser.Text = "Logged in as: None";
            // 
            // BorrowersForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1067, 692);
            Controls.Add(panel1);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txtSearch);
            Controls.Add(dgvItems);
            Controls.Add(dgvBorrowers);
            Controls.Add(btnClear);
            Controls.Add(btnDelete);
            Controls.Add(btnUpdate);
            Controls.Add(btnAdd);
            Controls.Add(txtPhone);
            Controls.Add(txtEmail);
            Controls.Add(txtFullName);
            Controls.Add(txtBorrowerCode);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Margin = new Padding(4, 5, 4, 5);
            Name = "BorrowersForm";
            Text = "BorrowersForm";
            Load += BorrowersForm_Load;
            ((System.ComponentModel.ISupportInitialize)dgvBorrowers).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtBorrowerCode;
        private TextBox txtFullName;
        private TextBox txtEmail;
        private TextBox txtPhone;
        private Button btnAdd;
        private Button btnUpdate;
        private Button btnDelete;
        private Button btnClear;
        private DataGridView dgvBorrowers;
        private Label dgvItems;
        private TextBox txtSearch;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Panel panel1;
        private PictureBox pictureBox1;
        private Label label5;
        private Label lblCurrentUser;
    }
}