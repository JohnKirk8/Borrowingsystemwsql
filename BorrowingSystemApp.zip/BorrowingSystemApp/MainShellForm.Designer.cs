﻿namespace BorrowingSystemApp
{
    partial class MainShellForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            cmbNavigation = new ComboBox();
            pnlMainContent = new Panel();
            SuspendLayout();
            // 
            // cmbNavigation
            // 
            cmbNavigation.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbNavigation.FormattingEnabled = true;
            cmbNavigation.Items.AddRange(new object[] { "Manage Items", "Manage Borrowers", "Transactions", "Reports" });
            cmbNavigation.Location = new Point(12, 12);
            cmbNavigation.Name = "cmbNavigation";
            cmbNavigation.Size = new Size(151, 28);
            cmbNavigation.TabIndex = 0;
            // 
            // pnlMainContent
            // 
            pnlMainContent.Location = new Point(198, 121);
            pnlMainContent.Name = "pnlMainContent";
            pnlMainContent.Size = new Size(385, 263);
            pnlMainContent.TabIndex = 1;
            // 
            // MainShellForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1333, 554);
            Controls.Add(pnlMainContent);
            Controls.Add(cmbNavigation);
            Name = "MainShellForm";
            Text = "MainShellForm";
            Load += MainShellForm_Load;
            ResumeLayout(false);
        }

        #endregion

        private ComboBox cmbNavigation;
        private Panel pnlMainContent;
    }
}