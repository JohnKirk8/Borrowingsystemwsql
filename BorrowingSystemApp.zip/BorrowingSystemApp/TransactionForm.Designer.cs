﻿namespace BorrowingSystemApp
{
    partial class TransactionForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TransactionForm));
            txtQty = new TextBox();
            dtpDueDate = new DateTimePicker();
            btnBorrow = new Button();
            btnReturn = new Button();
            dgvTransactions = new DataGridView();
            cmbBorrower = new ComboBox();
            cmbItem = new ComboBox();
            txtSearch = new TextBox();
            dgvItems = new Label();
            btnUpdate = new Button();
            btnDelete = new Button();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            panel1 = new Panel();
            label5 = new Label();
            pictureBox1 = new PictureBox();
            lblCurrentUser = new Label();
            ((System.ComponentModel.ISupportInitialize)dgvTransactions).BeginInit();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // txtQty
            // 
            txtQty.Location = new Point(232, 277);
            txtQty.Margin = new Padding(4, 5, 4, 5);
            txtQty.Name = "txtQty";
            txtQty.Size = new Size(160, 27);
            txtQty.TabIndex = 2;
            // 
            // dtpDueDate
            // 
            dtpDueDate.Location = new Point(127, 364);
            dtpDueDate.Margin = new Padding(4, 5, 4, 5);
            dtpDueDate.Name = "dtpDueDate";
            dtpDueDate.Size = new Size(265, 27);
            dtpDueDate.TabIndex = 3;
            // 
            // btnBorrow
            // 
            btnBorrow.Location = new Point(33, 534);
            btnBorrow.Margin = new Padding(4, 5, 4, 5);
            btnBorrow.Name = "btnBorrow";
            btnBorrow.Size = new Size(100, 35);
            btnBorrow.TabIndex = 4;
            btnBorrow.Text = "Borrow Item";
            btnBorrow.UseVisualStyleBackColor = true;
            // 
            // btnReturn
            // 
            btnReturn.Location = new Point(141, 534);
            btnReturn.Margin = new Padding(4, 5, 4, 5);
            btnReturn.Name = "btnReturn";
            btnReturn.Size = new Size(156, 35);
            btnReturn.TabIndex = 5;
            btnReturn.Text = "Return Selected Item";
            btnReturn.UseVisualStyleBackColor = true;
            // 
            // dgvTransactions
            // 
            dgvTransactions.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvTransactions.Location = new Point(440, 160);
            dgvTransactions.Margin = new Padding(4, 5, 4, 5);
            dgvTransactions.Name = "dgvTransactions";
            dgvTransactions.RowHeadersWidth = 51;
            dgvTransactions.Size = new Size(614, 231);
            dgvTransactions.TabIndex = 6;
            // 
            // cmbBorrower
            // 
            cmbBorrower.FormattingEnabled = true;
            cmbBorrower.Location = new Point(232, 160);
            cmbBorrower.Margin = new Padding(4, 5, 4, 5);
            cmbBorrower.Name = "cmbBorrower";
            cmbBorrower.Size = new Size(160, 28);
            cmbBorrower.TabIndex = 7;
            // 
            // cmbItem
            // 
            cmbItem.FormattingEnabled = true;
            cmbItem.Location = new Point(232, 218);
            cmbItem.Margin = new Padding(4, 5, 4, 5);
            cmbItem.Name = "cmbItem";
            cmbItem.Size = new Size(160, 28);
            cmbItem.TabIndex = 8;
            // 
            // txtSearch
            // 
            txtSearch.Location = new Point(507, 120);
            txtSearch.Margin = new Padding(4, 5, 4, 5);
            txtSearch.Name = "txtSearch";
            txtSearch.Size = new Size(252, 27);
            txtSearch.TabIndex = 12;
            // 
            // dgvItems
            // 
            dgvItems.AutoSize = true;
            dgvItems.Location = new Point(440, 125);
            dgvItems.Margin = new Padding(4, 0, 4, 0);
            dgvItems.Name = "dgvItems";
            dgvItems.Size = new Size(56, 20);
            dgvItems.TabIndex = 11;
            dgvItems.Text = "Search:";
            // 
            // btnUpdate
            // 
            btnUpdate.Location = new Point(304, 534);
            btnUpdate.Name = "btnUpdate";
            btnUpdate.Size = new Size(94, 35);
            btnUpdate.TabIndex = 13;
            btnUpdate.Text = "Update";
            btnUpdate.UseVisualStyleBackColor = true;
            // 
            // btnDelete
            // 
            btnDelete.Location = new Point(404, 534);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(94, 35);
            btnDelete.TabIndex = 14;
            btnDelete.Text = "Delete";
            btnDelete.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(38, 163);
            label1.Name = "label1";
            label1.Size = new Size(123, 20);
            label1.TabIndex = 15;
            label1.Text = "Borrower's name:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(38, 221);
            label2.Name = "label2";
            label2.Size = new Size(83, 20);
            label2.TabIndex = 16;
            label2.Text = "Item name:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(38, 277);
            label3.Name = "label3";
            label3.Size = new Size(68, 20);
            label3.TabIndex = 17;
            label3.Text = "Quantity:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(33, 369);
            label4.Name = "label4";
            label4.Size = new Size(73, 20);
            label4.TabIndex = 18;
            label4.Text = "Due date:";
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(30, 41, 59);
            panel1.Controls.Add(lblCurrentUser);
            panel1.Controls.Add(label5);
            panel1.Controls.Add(pictureBox1);
            panel1.Location = new Point(-8, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1088, 57);
            panel1.TabIndex = 19;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 16F);
            label5.ForeColor = SystemColors.ButtonHighlight;
            label5.Location = new Point(92, 9);
            label5.Name = "label5";
            label5.Size = new Size(204, 37);
            label5.TabIndex = 22;
            label5.Text = "Borrow / Return";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(14, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(71, 67);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 23;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // lblCurrentUser
            // 
            lblCurrentUser.AutoSize = true;
            lblCurrentUser.BackColor = SystemColors.ButtonHighlight;
            lblCurrentUser.Location = new Point(891, 23);
            lblCurrentUser.Name = "lblCurrentUser";
            lblCurrentUser.Size = new Size(137, 20);
            lblCurrentUser.TabIndex = 22;
            lblCurrentUser.Text = "Logged in as: None";
            // 
            // TransactionForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1067, 692);
            Controls.Add(panel1);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(btnDelete);
            Controls.Add(btnUpdate);
            Controls.Add(txtSearch);
            Controls.Add(dgvItems);
            Controls.Add(cmbItem);
            Controls.Add(cmbBorrower);
            Controls.Add(dgvTransactions);
            Controls.Add(btnReturn);
            Controls.Add(btnBorrow);
            Controls.Add(dtpDueDate);
            Controls.Add(txtQty);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Margin = new Padding(4, 5, 4, 5);
            Name = "TransactionForm";
            Text = "TransactionForm";
            Load += TransactionForm_Load;
            ((System.ComponentModel.ISupportInitialize)dgvTransactions).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private TextBox txtQty;
        private DateTimePicker dtpDueDate;
        private Button btnBorrow;
        private Button btnReturn;
        private DataGridView dgvTransactions;
        private ComboBox cmbBorrower;
        private ComboBox cmbItem;
        private TextBox txtSearch;
        private Label dgvItems;
        private Button btnUpdate;
        private Button btnDelete;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Panel panel1;
        private Label label5;
        private PictureBox pictureBox1;
        private Label lblCurrentUser;
    }
}