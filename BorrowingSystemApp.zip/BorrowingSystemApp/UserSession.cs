﻿namespace BorrowingSystemApp
{
    public static class UserSession
    {
        public static int UserID { get; set; }
        public static string Username { get; set; }
        public static string FullName { get; set; }

        public static void ClearSession()
        {
            UserID = 0;
            Username = string.Empty;
            FullName = string.Empty;
        }
    }
}