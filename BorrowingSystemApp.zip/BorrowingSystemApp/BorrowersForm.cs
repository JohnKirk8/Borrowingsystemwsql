﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace BorrowingSystemApp
{
    public partial class BorrowersForm : Form
    {
        int selectedBorrowerID = 0;

        public BorrowersForm()
        {
            InitializeComponent();

            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.StartPosition = FormStartPosition.CenterScreen;

            // Wire up event handlers cleanly
            btnAdd.Click -= btnAdd_Click;
            btnAdd.Click += btnAdd_Click;

            btnUpdate.Click -= btnUpdate_Click;
            btnUpdate.Click += btnUpdate_Click;

            btnDelete.Click -= btnDelete_Click;
            btnDelete.Click += btnDelete_Click;

            btnClear.Click -= btnClear_Click;
            btnClear.Click += btnClear_Click;

            dgvBorrowers.CellClick -= dgvBorrowers_CellClick;
            dgvBorrowers.CellClick += dgvBorrowers_CellClick;

            txtSearch.TextChanged -= txtSearch_TextChanged;
            txtSearch.TextChanged += txtSearch_TextChanged;
        }

        private void BorrowersForm_Load(object sender, EventArgs e)
        {
            lblCurrentUser.Text = $"Logged in as: {UserSession.Username}";
            this.Text += $" | Active User: {UserSession.Username}";
            if (dgvBorrowers != null) dgvBorrowers.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

            // Apply Modern UI Visuals Automatically
            ApplyModernDesign();

            LoadBorrowers();
        }

        private void LoadBorrowers(string search = "")
        {
            using (SqlConnection conn = new SqlConnection(DbConfig.ConnectionString))
            {
                try
                {
                    conn.Open();
                    string query = @"SELECT 
                                        BorrowerID, 
                                        BorrowerCode AS [Borrower Code], 
                                        FullName AS [Full Name], 
                                        Email AS [Email Address], 
                                        Phone AS [Phone Number] 
                                    FROM Borrowers 
                                    WHERE FullName LIKE @Search OR BorrowerCode LIKE @Search OR Email LIKE @Search
                                    ORDER BY BorrowerID DESC";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@Search", $"%{search}%");
                        SqlDataAdapter da = new SqlDataAdapter(cmd);
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        if (dgvBorrowers != null)
                        {
                            dgvBorrowers.DataSource = dt;

                            if (dgvBorrowers.Columns["BorrowerID"] != null)
                                dgvBorrowers.Columns["BorrowerID"].Visible = false;
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error loading borrowers: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            if (txtSearch != null)
                LoadBorrowers(txtSearch.Text.Trim());
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            string code = txtBorrowerCode.Text.Trim();
            string name = txtFullName.Text.Trim();
            string email = txtEmail.Text.Trim();
            string phone = txtPhone.Text.Trim();

            // 1. Mandatory Fields Validation
            if (string.IsNullOrWhiteSpace(code))
            {
                MessageBox.Show("Please enter a Borrower Code (e.g., BRW-001).", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtBorrowerCode.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(name))
            {
                MessageBox.Show("Please enter the Borrower's Full Name.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtFullName.Focus();
                return;
            }

            // 2. Format Validation for Optional Fields
            if (!string.IsNullOrWhiteSpace(email) && (!email.Contains("@") || !email.Contains(".")))
            {
                MessageBox.Show("Please enter a valid Email Address.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtEmail.Focus();
                return;
            }

            if (!string.IsNullOrWhiteSpace(phone) && !long.TryParse(phone.Replace("-", "").Replace(" ", "").Replace("+", ""), out _))
            {
                MessageBox.Show("Please enter a valid Phone Number containing digits only.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtPhone.Focus();
                return;
            }

            using (SqlConnection conn = new SqlConnection(DbConfig.ConnectionString))
            {
                try
                {
                    conn.Open();

                    // 3. Duplicate Code Check
                    string checkCodeQuery = "SELECT COUNT(*) FROM Borrowers WHERE BorrowerCode = @Code";
                    using (SqlCommand checkCmd = new SqlCommand(checkCodeQuery, conn))
                    {
                        checkCmd.Parameters.AddWithValue("@Code", code);
                        int exists = (int)checkCmd.ExecuteScalar();
                        if (exists > 0)
                        {
                            MessageBox.Show("This Borrower Code is already assigned to another borrower. Please use a unique code.", "Duplicate Code Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }
                    }

                    // 4. Parameterized Insert Statement
                    string query = "INSERT INTO Borrowers (BorrowerCode, FullName, Email, Phone) VALUES (@Code, @Name, @Email, @Phone)";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@Code", code);
                        cmd.Parameters.AddWithValue("@Name", name);
                        cmd.Parameters.AddWithValue("@Email", string.IsNullOrWhiteSpace(email) ? (object)DBNull.Value : email);
                        cmd.Parameters.AddWithValue("@Phone", string.IsNullOrWhiteSpace(phone) ? (object)DBNull.Value : phone);
                        cmd.ExecuteNonQuery();
                    }

                    // 5. Write to Audit Log
                    AuditLogger.Log("INSERT", $"Borrower Code: {code}", $"Added borrower {name}");

                    MessageBox.Show("Borrower added successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    ClearForm();
                    LoadBorrowers();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error adding borrower: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (selectedBorrowerID == 0)
            {
                MessageBox.Show("Please select a borrower from the table first.", "Selection Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string code = txtBorrowerCode.Text.Trim();
            string name = txtFullName.Text.Trim();
            string email = txtEmail.Text.Trim();
            string phone = txtPhone.Text.Trim();

            // Mandatory Validation
            if (string.IsNullOrWhiteSpace(code))
            {
                MessageBox.Show("Borrower Code cannot be empty.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (string.IsNullOrWhiteSpace(name))
            {
                MessageBox.Show("Full Name cannot be empty.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Update Confirmation Dialog (Rubric Requirement)
            DialogResult confirm = MessageBox.Show("Are you sure you want to update this borrower's details?", "Confirm Update", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (confirm != DialogResult.Yes) return;

            using (SqlConnection conn = new SqlConnection(DbConfig.ConnectionString))
            {
                try
                {
                    conn.Open();

                    // Check duplicate code against other records
                    string checkCodeQuery = "SELECT COUNT(*) FROM Borrowers WHERE BorrowerCode = @Code AND BorrowerID <> @ID";
                    using (SqlCommand checkCmd = new SqlCommand(checkCodeQuery, conn))
                    {
                        checkCmd.Parameters.AddWithValue("@Code", code);
                        checkCmd.Parameters.AddWithValue("@ID", selectedBorrowerID);
                        int exists = (int)checkCmd.ExecuteScalar();
                        if (exists > 0)
                        {
                            MessageBox.Show("This Borrower Code is already used by another record.", "Duplicate Code Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }
                    }

                    string query = "UPDATE Borrowers SET BorrowerCode=@Code, FullName=@Name, Email=@Email, Phone=@Phone WHERE BorrowerID=@ID";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@ID", selectedBorrowerID);
                        cmd.Parameters.AddWithValue("@Code", code);
                        cmd.Parameters.AddWithValue("@Name", name);
                        cmd.Parameters.AddWithValue("@Email", string.IsNullOrWhiteSpace(email) ? (object)DBNull.Value : email);
                        cmd.Parameters.AddWithValue("@Phone", string.IsNullOrWhiteSpace(phone) ? (object)DBNull.Value : phone);
                        cmd.ExecuteNonQuery();
                    }

                    // Write to Audit Log
                    AuditLogger.Log("UPDATE", $"Borrower ID: {selectedBorrowerID}", $"Updated details for {name} ({code})");

                    MessageBox.Show("Borrower updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    ClearForm();
                    LoadBorrowers();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error updating borrower: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (selectedBorrowerID == 0)
            {
                MessageBox.Show("Please select a borrower from the table first.", "Selection Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DialogResult confirm = MessageBox.Show("Are you sure you want to delete this borrower?", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (confirm != DialogResult.Yes) return;

            using (SqlConnection conn = new SqlConnection(DbConfig.ConnectionString))
            {
                try
                {
                    conn.Open();
                    string query = "DELETE FROM Borrowers WHERE BorrowerID=@ID";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@ID", selectedBorrowerID);
                        cmd.ExecuteNonQuery();
                    }

                    // Write to Audit Log
                    AuditLogger.Log("DELETE", $"Borrower ID: {selectedBorrowerID}", $"Deleted borrower: {txtFullName.Text.Trim()}");

                    MessageBox.Show("Borrower deleted successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    ClearForm();
                    LoadBorrowers();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error deleting borrower: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void dgvBorrowers_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && dgvBorrowers != null)
            {
                DataGridViewRow row = dgvBorrowers.Rows[e.RowIndex];
                selectedBorrowerID = Convert.ToInt32(row.Cells["BorrowerID"].Value);
                txtBorrowerCode.Text = row.Cells["Borrower Code"].Value?.ToString() ?? "";
                txtFullName.Text = row.Cells["Full Name"].Value?.ToString() ?? "";
                txtEmail.Text = row.Cells["Email Address"].Value?.ToString() ?? "";
                txtPhone.Text = row.Cells["Phone Number"].Value?.ToString() ?? "";
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearForm();
        }

        private void ClearForm()
        {
            selectedBorrowerID = 0;
            txtBorrowerCode.Clear();
            txtFullName.Clear();
            txtEmail.Clear();
            txtPhone.Clear();
        }

        #region Modern UI Styling

        private void ApplyModernDesign()
        {
            // Form Level Styling
            this.BackColor = Color.FromArgb(244, 246, 249);
            this.Font = new Font("Segoe UI", 9.5f, FontStyle.Regular);

            // Header Panel Styling (if named pnlHeader)
            Control[] headers = Controls.Find("pnlHeader", true);
            if (headers.Length > 0)
            {
                headers[0].BackColor = Color.FromArgb(30, 41, 59);
            }

            // Find and style buttons safely
            Control[] btnAddArr = Controls.Find("btnAdd", true);
            if (btnAddArr.Length > 0 && btnAddArr[0] is Button btnAddCtrl) StyleButton(btnAddCtrl, Color.FromArgb(37, 99, 235)); // Royal Blue
            else if (btnAdd != null) StyleButton(btnAdd, Color.FromArgb(37, 99, 235));

            Control[] btnUpdateArr = Controls.Find("btnUpdate", true);
            if (btnUpdateArr.Length > 0 && btnUpdateArr[0] is Button btnUpdateCtrl) StyleButton(btnUpdateCtrl, Color.FromArgb(217, 119, 6)); // Warm Amber
            else if (btnUpdate != null) StyleButton(btnUpdate, Color.FromArgb(217, 119, 6));

            Control[] btnDeleteArr = Controls.Find("btnDelete", true);
            if (btnDeleteArr.Length > 0 && btnDeleteArr[0] is Button btnDeleteCtrl) StyleButton(btnDeleteCtrl, Color.FromArgb(220, 38, 38)); // Crimson Red
            else if (btnDelete != null) StyleButton(btnDelete, Color.FromArgb(220, 38, 38));

            Control[] btnClearArr = Controls.Find("btnClear", true);
            if (btnClearArr.Length > 0 && btnClearArr[0] is Button btnClearCtrl) StyleButton(btnClearCtrl, Color.FromArgb(100, 116, 139)); // Slate Gray
            else if (btnClear != null) StyleButton(btnClear, Color.FromArgb(100, 116, 139));

            // DataGridView Table Refresh
            if (dgvBorrowers != null)
            {
                StyleDataGridView(dgvBorrowers);
            }
        }

        private void StyleButton(Button btn, Color backColor)
        {
            if (btn == null) return;

            btn.FlatStyle = FlatStyle.Flat;
            btn.FlatAppearance.BorderSize = 0;
            btn.BackColor = backColor;
            btn.ForeColor = Color.White;
            btn.Font = new Font("Segoe UI", 9.0f, FontStyle.Bold);
            btn.Cursor = Cursors.Hand;
            btn.Height = 36;
        }

        private void StyleDataGridView(DataGridView dgv)
        {
            if (dgv == null) return;

            // Background & Grid Lines
            dgv.BackgroundColor = Color.White;
            dgv.BorderStyle = BorderStyle.None;
            dgv.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            dgv.GridColor = Color.FromArgb(230, 235, 240);

            // Header Row
            dgv.EnableHeadersVisualStyles = false;
            dgv.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dgv.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(30, 41, 59); // Dark Navy
            dgv.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dgv.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 9.5f, FontStyle.Bold);
            dgv.ColumnHeadersHeight = 38;

            // Data Rows
            dgv.DefaultCellStyle.Font = new Font("Segoe UI", 9.5f, FontStyle.Regular);
            dgv.DefaultCellStyle.ForeColor = Color.FromArgb(15, 23, 42);
            dgv.DefaultCellStyle.SelectionBackColor = Color.FromArgb(224, 231, 255); // Soft Indigo Highlight
            dgv.DefaultCellStyle.SelectionForeColor = Color.FromArgb(30, 58, 138);
            dgv.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(248, 250, 252); // Soft Zebra Striping
            dgv.RowTemplate.Height = 34;

            // Layout Settings
            dgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgv.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgv.MultiSelect = false;
        }

        #endregion
    }
}