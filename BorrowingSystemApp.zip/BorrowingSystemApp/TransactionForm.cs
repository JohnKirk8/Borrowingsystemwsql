﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace BorrowingSystemApp
{
    public partial class TransactionForm : Form
    {
        int selectedTransactionID = 0;

        public TransactionForm()
        {
            InitializeComponent();

            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.StartPosition = FormStartPosition.CenterScreen;

            WireUpEvents();
        }

        private void WireUpEvents()
        {
            Control[] btns = Controls.Find("btnClear", true);
            if (btns.Length > 0 && btns[0] is Button btnClear)
            {
                btnClear.Click -= btnClear_Click;
                btnClear.Click += btnClear_Click;
            }

            Control[] btnBorrowArr = Controls.Find("btnBorrow", true);
            if (btnBorrowArr.Length > 0 && btnBorrowArr[0] is Button btnBorrow)
            {
                btnBorrow.Click -= btnBorrow_Click;
                btnBorrow.Click += btnBorrow_Click;
            }

            Control[] btnReturnArr = Controls.Find("btnReturn", true);
            if (btnReturnArr.Length > 0 && btnReturnArr[0] is Button btnReturn)
            {
                btnReturn.Click -= btnReturn_Click;
                btnReturn.Click += btnReturn_Click;
            }

            Control[] btnUpdateArr = Controls.Find("btnUpdate", true);
            if (btnUpdateArr.Length > 0 && btnUpdateArr[0] is Button btnUpdate)
            {
                btnUpdate.Click -= btnUpdate_Click;
                btnUpdate.Click += btnUpdate_Click;
            }

            Control[] btnDeleteArr = Controls.Find("btnDelete", true);
            if (btnDeleteArr.Length > 0 && btnDeleteArr[0] is Button btnDelete)
            {
                btnDelete.Click -= btnDelete_Click;
                btnDelete.Click += btnDelete_Click;
            }

            if (Controls.Find("dgvTransactions", true).Length > 0 && dgvTransactions != null)
            {
                dgvTransactions.CellClick -= dgvTransactions_CellClick;
                dgvTransactions.CellClick += dgvTransactions_CellClick;

                dgvTransactions.CellFormatting -= dgvTransactions_CellFormatting;
                dgvTransactions.CellFormatting += dgvTransactions_CellFormatting;
            }

            if (Controls.Find("txtSearch", true).Length > 0 && txtSearch != null)
            {
                txtSearch.TextChanged -= txtSearch_TextChanged;
                txtSearch.TextChanged += txtSearch_TextChanged;
            }
        }

        private void TransactionForm_Load(object sender, EventArgs e)
        {
            lblCurrentUser.Text = $"Logged in as: {UserSession.Username}";
            this.Text += $" | Active User: {UserSession.Username}";
            if (dgvTransactions != null) dgvTransactions.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

            // Apply Modern UI Visuals Automatically
            ApplyModernDesign();

            SetMinDueDate();

            LoadBorrowersDropdown();
            LoadItemsDropdown();
            LoadTransactions();
        }

        private void SetMinDueDate()
        {
            Control[] d1 = Controls.Find("dtpDueDate", true);
            if (d1.Length > 0 && d1[0] is DateTimePicker dtp1) dtp1.MinDate = DateTime.Today;

            Control[] d2 = Controls.Find("dtpBorrowDate", true);
            if (d2.Length > 0 && d2[0] is DateTimePicker dtp2) dtp2.MinDate = DateTime.Today;
        }

        private void LoadBorrowersDropdown()
        {
            using (SqlConnection conn = new SqlConnection(DbConfig.ConnectionString))
            {
                try
                {
                    conn.Open();
                    string query = "SELECT BorrowerID, FullName + ' (' + BorrowerCode + ')' AS DisplayName FROM Borrowers ORDER BY FullName";
                    SqlDataAdapter da = new SqlDataAdapter(query, conn);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    if (cmbBorrower != null)
                    {
                        cmbBorrower.DataSource = dt;
                        cmbBorrower.DisplayMember = "DisplayName";
                        cmbBorrower.ValueMember = "BorrowerID";
                        cmbBorrower.SelectedIndex = -1;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error loading borrowers: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void LoadItemsDropdown()
        {
            using (SqlConnection conn = new SqlConnection(DbConfig.ConnectionString))
            {
                try
                {
                    conn.Open();
                    string query = "SELECT ItemID, ItemName + ' (Available: ' + CAST(AvailableQty AS VARCHAR) + ')' AS DisplayName FROM Items WHERE AvailableQty > 0 ORDER BY ItemName";
                    SqlDataAdapter da = new SqlDataAdapter(query, conn);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    if (cmbItem != null)
                    {
                        cmbItem.DataSource = dt;
                        cmbItem.DisplayMember = "DisplayName";
                        cmbItem.ValueMember = "ItemID";
                        cmbItem.SelectedIndex = -1;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error loading items: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void LoadTransactions(string search = "")
        {
            using (SqlConnection conn = new SqlConnection(DbConfig.ConnectionString))
            {
                try
                {
                    conn.Open();
                    string query = @"SELECT 
                                        t.TransactionID, 
                                        b.FullName AS [Borrower Name], 
                                        i.ItemName AS [Item Name], 
                                        d.Quantity AS [Quantity], 
                                        t.BorrowDate AS [Borrow Date], 
                                        t.DueDate AS [Due Date], 
                                        t.ReturnDate AS [Return Date], 
                                        t.Status AS [Status] 
                                    FROM BorrowTransactions t
                                    INNER JOIN Borrowers b ON t.BorrowerID = b.BorrowerID
                                    INNER JOIN BorrowDetails d ON t.TransactionID = d.TransactionID
                                    INNER JOIN Items i ON d.ItemID = i.ItemID
                                    WHERE b.FullName LIKE @Search OR i.ItemName LIKE @Search OR t.Status LIKE @Search
                                    ORDER BY t.TransactionID DESC";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@Search", $"%{search}%");
                        SqlDataAdapter da = new SqlDataAdapter(cmd);
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        if (dgvTransactions != null)
                        {
                            dgvTransactions.DataSource = dt;
                            if (dgvTransactions.Columns["TransactionID"] != null)
                                dgvTransactions.Columns["TransactionID"].Visible = false;
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error loading transactions: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private string GetQuantityText()
        {
            Control[] q1 = Controls.Find("txtQuantity", true);
            if (q1.Length > 0 && q1[0] is TextBox tb1) return tb1.Text.Trim();

            Control[] q2 = Controls.Find("txtQty", true);
            if (q2.Length > 0 && q2[0] is TextBox tb2) return tb2.Text.Trim();

            return "1";
        }

        private void SetQuantityText(string val)
        {
            Control[] q1 = Controls.Find("txtQuantity", true);
            if (q1.Length > 0 && q1[0] is TextBox tb1) { tb1.Text = val; return; }

            Control[] q2 = Controls.Find("txtQty", true);
            if (q2.Length > 0 && q2[0] is TextBox tb2) { tb2.Text = val; return; }
        }

        private DateTime GetDueDate()
        {
            Control[] d1 = Controls.Find("dtpDueDate", true);
            if (d1.Length > 0 && d1[0] is DateTimePicker dtp1) return dtp1.Value;

            Control[] d2 = Controls.Find("dtpBorrowDate", true);
            if (d2.Length > 0 && d2[0] is DateTimePicker dtp2) return dtp2.Value;

            return DateTime.Now.AddDays(7);
        }

        private void SetDueDate(DateTime dt)
        {
            Control[] d1 = Controls.Find("dtpDueDate", true);
            if (d1.Length > 0 && d1[0] is DateTimePicker dtp1)
            {
                if (dt < dtp1.MinDate) dtp1.MinDate = dt;
                dtp1.Value = dt;
                return;
            }

            Control[] d2 = Controls.Find("dtpBorrowDate", true);
            if (d2.Length > 0 && d2[0] is DateTimePicker dtp2)
            {
                if (dt < dtp2.MinDate) dtp2.MinDate = dt;
                dtp2.Value = dt;
                return;
            }
        }

        private void SelectDropdownByText(ComboBox cmb, string textToFind)
        {
            if (cmb == null || string.IsNullOrEmpty(textToFind)) return;
            for (int i = 0; i < cmb.Items.Count; i++)
            {
                string itemText = cmb.GetItemText(cmb.Items[i]);
                if (itemText.Contains(textToFind))
                {
                    cmb.SelectedIndex = i;
                    break;
                }
            }
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            if (txtSearch != null)
                LoadTransactions(txtSearch.Text.Trim());
        }

        private void dgvTransactions_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (e.RowIndex >= 0 && e.RowIndex < dgvTransactions.Rows.Count)
            {
                DataGridViewRow row = dgvTransactions.Rows[e.RowIndex];
                string status = row.Cells["Status"].Value?.ToString();

                if (status == "Borrowed")
                {
                    object dueDateObj = row.Cells["Due Date"].Value;
                    if (dueDateObj != null && DateTime.TryParse(dueDateObj.ToString(), out DateTime dueDate))
                    {
                        DateTime today = DateTime.Today;
                        int daysLeft = (dueDate.Date - today).Days;

                        if (daysLeft < 0)
                        {
                            e.CellStyle.BackColor = Color.LightCoral;
                            e.CellStyle.ForeColor = Color.White;
                        }
                        else if (daysLeft == 0)
                        {
                            e.CellStyle.BackColor = Color.Orange;
                            e.CellStyle.ForeColor = Color.Black;
                        }
                        else if (daysLeft >= 1 && daysLeft <= 3)
                        {
                            e.CellStyle.BackColor = Color.Khaki;
                            e.CellStyle.ForeColor = Color.Black;
                        }
                    }
                }
            }
        }

        private void btnBorrow_Click(object sender, EventArgs e)
        {
            if (cmbBorrower == null || cmbBorrower.SelectedValue == null)
            {
                MessageBox.Show("Please select a borrower.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (cmbItem == null || cmbItem.SelectedValue == null)
            {
                MessageBox.Show("Please select an item.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!int.TryParse(GetQuantityText(), out int qty) || qty <= 0)
            {
                MessageBox.Show("Please enter a valid quantity greater than 0.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DateTime dueDate = GetDueDate();
            if (dueDate.Date < DateTime.Today)
            {
                MessageBox.Show("Due date cannot be set before today's date.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int borrowerID = Convert.ToInt32(cmbBorrower.SelectedValue);
            int itemID = Convert.ToInt32(cmbItem.SelectedValue);

            using (SqlConnection conn = new SqlConnection(DbConfig.ConnectionString))
            {
                conn.Open();
                SqlTransaction transaction = conn.BeginTransaction();

                try
                {
                    string checkQtyQuery = "SELECT AvailableQty FROM Items WHERE ItemID = @ItemID";
                    using (SqlCommand checkCmd = new SqlCommand(checkQtyQuery, conn, transaction))
                    {
                        checkCmd.Parameters.AddWithValue("@ItemID", itemID);
                        int availQty = Convert.ToInt32(checkCmd.ExecuteScalar() ?? 0);

                        if (qty > availQty)
                        {
                            MessageBox.Show($"Requested quantity ({qty}) exceeds available stock ({availQty}).", "Stock Insufficient", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            transaction.Rollback();
                            return;
                        }
                    }

                    string insertTransQuery = @"INSERT INTO BorrowTransactions (BorrowerID, BorrowDate, DueDate, Status) 
                                               VALUES (@BorrowerID, GETDATE(), @DueDate, 'Borrowed');
                                               SELECT SCOPE_IDENTITY();";
                    int transID = 0;
                    using (SqlCommand cmd = new SqlCommand(insertTransQuery, conn, transaction))
                    {
                        cmd.Parameters.AddWithValue("@BorrowerID", borrowerID);
                        cmd.Parameters.AddWithValue("@DueDate", dueDate);
                        transID = Convert.ToInt32(cmd.ExecuteScalar());
                    }

                    string insertDetailQuery = @"INSERT INTO BorrowDetails (TransactionID, ItemID, Quantity) 
                                               VALUES (@TransID, @ItemID, @Qty);";
                    using (SqlCommand cmd = new SqlCommand(insertDetailQuery, conn, transaction))
                    {
                        cmd.Parameters.AddWithValue("@TransID", transID);
                        cmd.Parameters.AddWithValue("@ItemID", itemID);
                        cmd.Parameters.AddWithValue("@Qty", qty);
                        cmd.ExecuteNonQuery();
                    }

                    string updateItemQuery = "UPDATE Items SET AvailableQty = AvailableQty - @Qty WHERE ItemID = @ItemID";
                    using (SqlCommand updateCmd = new SqlCommand(updateItemQuery, conn, transaction))
                    {
                        updateCmd.Parameters.AddWithValue("@Qty", qty);
                        updateCmd.Parameters.AddWithValue("@ItemID", itemID);
                        updateCmd.ExecuteNonQuery();
                    }

                    transaction.Commit();
                    MessageBox.Show("Item borrowed successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    ClearForm();
                    LoadTransactions();
                    LoadItemsDropdown();
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    MessageBox.Show("Error processing borrow transaction: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (selectedTransactionID == 0)
            {
                MessageBox.Show("Please select a transaction from the table to update.", "Selection Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!int.TryParse(GetQuantityText(), out int newQty) || newQty <= 0)
            {
                MessageBox.Show("Please enter a valid quantity greater than 0.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DateTime newDueDate = GetDueDate();
            if (newDueDate.Date < DateTime.Today)
            {
                MessageBox.Show("Due date cannot be set before today's date.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (SqlConnection conn = new SqlConnection(DbConfig.ConnectionString))
            {
                conn.Open();
                SqlTransaction transaction = conn.BeginTransaction();

                try
                {
                    string fetchDetailQuery = @"SELECT d.ItemID, d.Quantity, t.Status 
                                                FROM BorrowTransactions t
                                                INNER JOIN BorrowDetails d ON t.TransactionID = d.TransactionID
                                                WHERE t.TransactionID = @TxID";

                    int itemID = 0;
                    int oldQty = 0;
                    string status = "";

                    using (SqlCommand cmd = new SqlCommand(fetchDetailQuery, conn, transaction))
                    {
                        cmd.Parameters.AddWithValue("@TxID", selectedTransactionID);
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                itemID = Convert.ToInt32(reader["ItemID"]);
                                oldQty = Convert.ToInt32(reader["Quantity"]);
                                status = reader["Status"].ToString();
                            }
                        }
                    }

                    if (status.Equals("Returned", StringComparison.OrdinalIgnoreCase))
                    {
                        MessageBox.Show("Cannot update a transaction that has already been returned.", "Update Blocked", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        transaction.Rollback();
                        return;
                    }

                    int qtyDiff = newQty - oldQty;

                    if (qtyDiff > 0)
                    {
                        string checkStockQuery = "SELECT AvailableQty FROM Items WHERE ItemID = @ItemID";
                        using (SqlCommand cmd = new SqlCommand(checkStockQuery, conn, transaction))
                        {
                            cmd.Parameters.AddWithValue("@ItemID", itemID);
                            int availQty = Convert.ToInt32(cmd.ExecuteScalar() ?? 0);
                            if (qtyDiff > availQty)
                            {
                                MessageBox.Show($"Cannot increase quantity by {qtyDiff}. Only {availQty} more available in stock.", "Stock Insufficient", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                transaction.Rollback();
                                return;
                            }
                        }
                    }

                    string updateDetailQuery = "UPDATE BorrowDetails SET Quantity = @NewQty WHERE TransactionID = @TxID";
                    using (SqlCommand cmd = new SqlCommand(updateDetailQuery, conn, transaction))
                    {
                        cmd.Parameters.AddWithValue("@NewQty", newQty);
                        cmd.Parameters.AddWithValue("@TxID", selectedTransactionID);
                        cmd.ExecuteNonQuery();
                    }

                    string updateStockQuery = "UPDATE Items SET AvailableQty = AvailableQty - @Diff WHERE ItemID = @ItemID";
                    using (SqlCommand cmd = new SqlCommand(updateStockQuery, conn, transaction))
                    {
                        cmd.Parameters.AddWithValue("@Diff", qtyDiff);
                        cmd.Parameters.AddWithValue("@ItemID", itemID);
                        cmd.ExecuteNonQuery();
                    }

                    string updateTransQuery = "UPDATE BorrowTransactions SET DueDate = @DueDate WHERE TransactionID = @TxID";
                    using (SqlCommand cmd = new SqlCommand(updateTransQuery, conn, transaction))
                    {
                        cmd.Parameters.AddWithValue("@DueDate", newDueDate);
                        cmd.Parameters.AddWithValue("@TxID", selectedTransactionID);
                        cmd.ExecuteNonQuery();
                    }

                    transaction.Commit();
                    MessageBox.Show("Transaction updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    ClearForm();
                    LoadTransactions();
                    LoadItemsDropdown();
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    MessageBox.Show("Error updating transaction: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (selectedTransactionID == 0)
            {
                MessageBox.Show("Please select a transaction from the table to delete.", "Selection Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DialogResult confirm = MessageBox.Show(
                "Are you sure you want to delete this transaction record?\n\nIf the item is currently borrowed, deleting this record will automatically restore the item stock.",
                "Confirm Deletion",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (confirm != DialogResult.Yes) return;

            using (SqlConnection conn = new SqlConnection(DbConfig.ConnectionString))
            {
                conn.Open();
                SqlTransaction transaction = conn.BeginTransaction();

                try
                {
                    string fetchQuery = @"SELECT d.ItemID, d.Quantity, t.Status 
                                          FROM BorrowTransactions t 
                                          INNER JOIN BorrowDetails d ON t.TransactionID = d.TransactionID 
                                          WHERE t.TransactionID = @TxID";

                    int itemID = 0;
                    int qty = 0;
                    string status = "";

                    using (SqlCommand cmd = new SqlCommand(fetchQuery, conn, transaction))
                    {
                        cmd.Parameters.AddWithValue("@TxID", selectedTransactionID);
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                itemID = Convert.ToInt32(reader["ItemID"]);
                                qty = Convert.ToInt32(reader["Quantity"]);
                                status = reader["Status"].ToString();
                            }
                        }
                    }

                    if (status.Equals("Borrowed", StringComparison.OrdinalIgnoreCase) && itemID > 0)
                    {
                        string restoreStockQuery = "UPDATE Items SET AvailableQty = AvailableQty + @Qty WHERE ItemID = @ItemID";
                        using (SqlCommand cmd = new SqlCommand(restoreStockQuery, conn, transaction))
                        {
                            cmd.Parameters.AddWithValue("@Qty", qty);
                            cmd.Parameters.AddWithValue("@ItemID", itemID);
                            cmd.ExecuteNonQuery();
                        }
                    }

                    string deleteDetailsQuery = "DELETE FROM BorrowDetails WHERE TransactionID = @TxID";
                    using (SqlCommand cmd = new SqlCommand(deleteDetailsQuery, conn, transaction))
                    {
                        cmd.Parameters.AddWithValue("@TxID", selectedTransactionID);
                        cmd.ExecuteNonQuery();
                    }

                    string deleteTransQuery = "DELETE FROM BorrowTransactions WHERE TransactionID = @TxID";
                    using (SqlCommand cmd = new SqlCommand(deleteTransQuery, conn, transaction))
                    {
                        cmd.Parameters.AddWithValue("@TxID", selectedTransactionID);
                        cmd.ExecuteNonQuery();
                    }

                    transaction.Commit();
                    MessageBox.Show("Transaction record deleted successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    ClearForm();
                    LoadTransactions();
                    LoadItemsDropdown();
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    MessageBox.Show("Error deleting transaction: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            if (selectedTransactionID == 0)
            {
                MessageBox.Show("Please select a transaction from the table first.", "Selection Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (SqlConnection conn = new SqlConnection(DbConfig.ConnectionString))
            {
                conn.Open();
                SqlTransaction transaction = conn.BeginTransaction();

                try
                {
                    string getTxQuery = @"SELECT d.ItemID, d.Quantity, t.Status 
                                          FROM BorrowTransactions t 
                                          INNER JOIN BorrowDetails d ON t.TransactionID = d.TransactionID 
                                          WHERE t.TransactionID = @TxID";
                    int itemID = 0;
                    int qty = 0;
                    string status = "";

                    using (SqlCommand cmd = new SqlCommand(getTxQuery, conn, transaction))
                    {
                        cmd.Parameters.AddWithValue("@TxID", selectedTransactionID);
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                itemID = Convert.ToInt32(reader["ItemID"]);
                                qty = Convert.ToInt32(reader["Quantity"]);
                                status = reader["Status"].ToString();
                            }
                        }
                    }

                    if (status.Equals("Returned", StringComparison.OrdinalIgnoreCase))
                    {
                        MessageBox.Show("This transaction has already been returned.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        transaction.Rollback();
                        return;
                    }

                    string updateTxQuery = "UPDATE BorrowTransactions SET Status = 'Returned', ReturnDate = GETDATE() WHERE TransactionID = @TxID";
                    using (SqlCommand cmd = new SqlCommand(updateTxQuery, conn, transaction))
                    {
                        cmd.Parameters.AddWithValue("@TxID", selectedTransactionID);
                        cmd.ExecuteNonQuery();
                    }

                    string restoreQtyQuery = "UPDATE Items SET AvailableQty = AvailableQty + @Qty WHERE ItemID = @ItemID";
                    using (SqlCommand cmd = new SqlCommand(restoreQtyQuery, conn, transaction))
                    {
                        cmd.Parameters.AddWithValue("@Qty", qty);
                        cmd.Parameters.AddWithValue("@ItemID", itemID);
                        cmd.ExecuteNonQuery();
                    }

                    transaction.Commit();
                    MessageBox.Show("Item returned successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    ClearForm();
                    LoadTransactions();
                    LoadItemsDropdown();
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    MessageBox.Show("Error processing return transaction: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void dgvTransactions_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && dgvTransactions != null)
            {
                DataGridViewRow row = dgvTransactions.Rows[e.RowIndex];
                if (row.Cells["TransactionID"].Value != null && int.TryParse(row.Cells["TransactionID"].Value.ToString(), out int id))
                {
                    selectedTransactionID = id;

                    string borrowerName = row.Cells["Borrower Name"].Value?.ToString();
                    string itemName = row.Cells["Item Name"].Value?.ToString();
                    string qtyStr = row.Cells["Quantity"].Value?.ToString();
                    object dueDateObj = row.Cells["Due Date"].Value;

                    SetQuantityText(qtyStr);

                    if (dueDateObj != null && DateTime.TryParse(dueDateObj.ToString(), out DateTime dueDate))
                    {
                        SetDueDate(dueDate);
                    }

                    SelectDropdownByText(cmbBorrower, borrowerName);
                    SelectDropdownByText(cmbItem, itemName);
                }
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearForm();
        }

        private void ClearForm()
        {
            selectedTransactionID = 0;
            if (cmbBorrower != null) cmbBorrower.SelectedIndex = -1;
            if (cmbItem != null) cmbItem.SelectedIndex = -1;

            SetQuantityText("");
            SetMinDueDate();
        }

        #region Modern UI Styling

        private void ApplyModernDesign()
        {
            // Form Level Styling
            this.BackColor = Color.FromArgb(244, 246, 249);
            this.Font = new Font("Segoe UI", 9.5f, FontStyle.Regular);

            // Header Panel Styling (if named pnlHeader)
            Control[] headers = Controls.Find("pnlHeader", true);
            if (headers.Length > 0)
            {
                headers[0].BackColor = Color.FromArgb(30, 41, 59);
            }

            // Find and style buttons safely
            Control[] btnBorrowArr = Controls.Find("btnBorrow", true);
            if (btnBorrowArr.Length > 0 && btnBorrowArr[0] is Button btnBorrow) StyleButton(btnBorrow, Color.FromArgb(37, 99, 235)); // Royal Blue

            Control[] btnReturnArr = Controls.Find("btnReturn", true);
            if (btnReturnArr.Length > 0 && btnReturnArr[0] is Button btnReturn) StyleButton(btnReturn, Color.FromArgb(16, 185, 129)); // Emerald Green

            Control[] btnUpdateArr = Controls.Find("btnUpdate", true);
            if (btnUpdateArr.Length > 0 && btnUpdateArr[0] is Button btnUpdate) StyleButton(btnUpdate, Color.FromArgb(217, 119, 6)); // Warm Amber

            Control[] btnDeleteArr = Controls.Find("btnDelete", true);
            if (btnDeleteArr.Length > 0 && btnDeleteArr[0] is Button btnDelete) StyleButton(btnDelete, Color.FromArgb(220, 38, 38)); // Crimson Red

            Control[] btnClearArr = Controls.Find("btnClear", true);
            if (btnClearArr.Length > 0 && btnClearArr[0] is Button btnClear) StyleButton(btnClear, Color.FromArgb(100, 116, 139)); // Slate Gray

            // DataGridView Table Refresh
            StyleDataGridView(dgvTransactions);
        }

        private void StyleButton(Button btn, Color backColor)
        {
            if (btn == null) return;

            btn.FlatStyle = FlatStyle.Flat;
            btn.FlatAppearance.BorderSize = 0;
            btn.BackColor = backColor;
            btn.ForeColor = Color.White;
            btn.Font = new Font("Segoe UI", 9.0f, FontStyle.Bold);
            btn.Cursor = Cursors.Hand;
            btn.Height = 36;
        }

        private void StyleDataGridView(DataGridView dgv)
        {
            if (dgv == null) return;

            // Background & Grid Lines
            dgv.BackgroundColor = Color.White;
            dgv.BorderStyle = BorderStyle.None;
            dgv.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            dgv.GridColor = Color.FromArgb(230, 235, 240);

            // Header Row
            dgv.EnableHeadersVisualStyles = false;
            dgv.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dgv.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(30, 41, 59); // Dark Navy
            dgv.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dgv.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 9.5f, FontStyle.Bold);
            dgv.ColumnHeadersHeight = 38;

            // Data Rows
            dgv.DefaultCellStyle.Font = new Font("Segoe UI", 9.5f, FontStyle.Regular);
            dgv.DefaultCellStyle.ForeColor = Color.FromArgb(15, 23, 42);
            dgv.DefaultCellStyle.SelectionBackColor = Color.FromArgb(224, 231, 255); // Soft Indigo Highlight
            dgv.DefaultCellStyle.SelectionForeColor = Color.FromArgb(30, 58, 138);
            dgv.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(248, 250, 252); // Soft Zebra Striping
            dgv.RowTemplate.Height = 34;

            // Layout Settings
            dgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgv.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgv.MultiSelect = false;
        }

        #endregion

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}